exec(open('tools/conv.py').read().split('# gun:')[0])
def collect(f,root=None,skip=(),name='m',mx=512,tagger=None,keep=None):
    g=G(f);j=g.j;W,par=worlds(j);parts=[]
    def under(i):
        while i is not None:
            if i==root:return True
            i=par.get(i)
        return False
    def anc(i):
        while i is not None:
            yield i;i=par.get(i)
    for i,n in enumerate(j['nodes']):
        if 'mesh' not in n or (root is not None and not under(i)) or any(k in n.get('name','').lower() for k in skip):continue
        for p in j['meshes'][n['mesh']]['primitives']:
            if p.get('mode',4)!=4:continue
            a=p['attributes'];P=g.acc(a['POSITION']).astype(float);Nn=g.acc(a['NORMAL']).astype(float) if 'NORMAL' in a else np.tile([0,1,0.],(len(P),1))
            Uv=g.acc(a['TEXCOORD_0']).astype(float) if 'TEXCOORD_0' in a else np.zeros((len(P),2))
            I=g.acc(p['indices']).reshape(-1).astype(np.int64) if 'indices' in p else np.arange(len(P))
            kv=None
            if 'skin' in n and 'JOINTS_0' in a:
                sk=j['skins'][n['skin']];ibm=g.acc(sk['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1)
                jm=np.array([W[jn]@ibm[k] for k,jn in enumerate(sk['joints'])]);J=g.acc(a['JOINTS_0']).astype(int);Wt=g.acc(a['WEIGHTS_0']).astype(float)
                M=np.einsum('nk,nkab->nab',Wt,jm[J]);ph=np.c_[P,np.ones(len(P))]
                P=np.einsum('nab,nb->na',M,ph)[:,:3];Nn=np.einsum('nab,nb->na',M[:,:3,:3],Nn)
                if tagger:
                    dj=J[np.arange(len(P)),Wt.argmax(1)];kv=[tagger(j,sk['joints'][q],anc) for q in dj]
            else:
                P=(np.c_[P,np.ones(len(P))]@W[i].T)[:,:3];Nn=Nn@np.linalg.inv(W[i][:3,:3])
                if tagger:kv=[tagger(j,i,anc)]*len(P)
            col,tx=g.tex(p['material'],mx,name) if 'material' in p else ([1,1,1,1],-1)
            if 'glass' in n.get('name','').lower():col=list(col);col[3]=min(col[3],.35)
            if kv is None:kv=[(0,-1)]*len(P)
            ids={};vk=np.array([ids.setdefault(k,len(ids)) for k in kv]);inv={v:k for k,v in ids.items()}
            T=I.reshape(-1,3);tk=np.where(vk[T[:,1]]==vk[T[:,2]],vk[T[:,1]],vk[T[:,0]])
            for u in np.unique(tk):
                sub=T[tk==u];used=np.unique(sub);rm=-np.ones(len(P),int);rm[used]=np.arange(len(used))
                tag,nd=inv[u];Pp=P[used]
                pv=(W[nd][:3,3] if nd>=0 else (Pp.min(0)+Pp.max(0))/2) if tag else np.zeros(3)
                parts.append(dict(P=Pp,N=Nn[used],U=Uv[used],I=rm[sub].reshape(-1),col=col,tx=tx,bb=(Pp.min(0)+Pp.max(0))/2,tag=tag,pv=np.array(pv,float)))
    return parts
def write(fn,parts,target,tf):
    allp=np.concatenate([p['P'] for p in parts]);lo=allp.min(0);hi=allp.max(0);tf(parts,lo,hi)
    tot=sum(len(p['I']) for p in parts if not p.get('tag'))//3 or 1;out=bytearray(struct.pack('<i',len(parts)));T=0
    for p in parts:
        if p.get('tag'):P,N,Uv,I=p['P'],p['N'],p['U'],p['I']
        else:P,N,Uv,I=decim(p['P'],p['N'],p['U'],p['I'],max(40,int(target*len(p['I'])//3/tot)))
        assert len(P)<65536;T+=len(I)//3;fnm=(p['tx'] if p['tx']!=-1 else '').encode()
        out+=struct.pack('<ii4fi',len(P),len(I),*p['col'][:4],len(fnm))+fnm+struct.pack('<i3f',p.get('tag',0),*p.get('pv',np.zeros(3)))+np.c_[P,N,Uv].astype('<f4').tobytes()+I.astype('<u2').tobytes()
    open(OUT+'m/'+fn,'wb').write(out);print(fn,T,'tris',len(out)//1024,'KB',sorted(set(p.get('tag',0) for p in parts)))
def mk(L,axis,ground,maxdim=False):
    def f(parts,lo,hi):
        s=L/((hi-lo).max() if maxdim else (hi-lo)[axis]);c=(lo+hi)/2;off=np.array([c[0],lo[1] if ground else c[1],c[2]])
        for p in parts:
            p['P']=(p['P']-off)*s
            if p.get('tag'):p['pv']=(p['pv']-off)*s
    return f
def tg_heli(j,i,anc):
    return {26:(1,-1),34:(2,-1),6:(8,-1)}.get(i,(0,-1))
def tg_tank(j,i,anc):
    N=j['nodes']
    for a in anc(i):
        nm=N[a].get('name','').lower()
        if 'wheel_' in nm and '_end' not in nm and 'mud' not in nm:return (5,a)
        if 'cannon_recoil' in nm:return (6,next(k for k,m in enumerate(N) if 'cannon_elevate' in m.get('name','').lower()))
        if 'cannon_elevate' in nm:return (4,a)
        if 'turret_pivot' in nm:return (3,a)
    return (0,-1)
def tg_canopy(j,i,anc):
    for a in anc(i):
        if 'canopy' in j['nodes'][a].get('name','').lower():return (8,-1)
    return (0,-1)
U_='/mnt/user-data/uploads/'
write('gun.bin',collect('تفنگ.glb',name='gun',mx=1024),12000,mk(.7,0,False))
write('gun2.bin',collect('تفنگ2.glb',name='gun2'),9000,mk(.7,0,False,True))
write('gun4.bin',collect('تفنگ4.glb',name='gun4'),9000,mk(.7,0,False,True))
pr=collect('سه_سرباز.glb',name='sol')
xs=sorted(set(round(p['bb'][0],3) for p in pr));gaps=sorted(range(len(xs)-1),key=lambda k:-(xs[k+1]-xs[k]))[:2];cuts=sorted((xs[k]+xs[k+1])/2 for k in gaps)
for s in range(3):write('sol%d.bin'%s,[dict(p) for p in pr if sum(p['bb'][0]>c for c in cuts)==s],7000,mk(1.8,1,True))
write('tank.bin',collect('تانک3.glb',root=3,name='tank',tagger=tg_tank),16000,mk(9.5,2,True))
write('heli.bin',collect('هلیکوپتر_جنگی.glb',root=3,skip=('wreck',),name='heli',tagger=tg_heli),12000,mk(12,2,False))
write('sandbag.bin',collect('کیسه_شن_.glb',name='bag'),3000,mk(1.0,0,True))
write('wire.bin',collect('سیم_خاردا_ر.glb',name='wire'),5000,mk(6,2,True))
write('tower.bin',collect('برج_.glb',name='tower'),12000,mk(14,0,True,True))
write('trailer.bin',collect('2_ماشین_تریلی_جنگی.glb',name='trailer'),16000,mk(12,0,True,True))
write('ammo.bin',collect('پک_گلوله.glb',name='ammo'),3000,mk(.7,0,True,True))
write('jet.bin',collect('جت.glb',name='jet'),12000,mk(14,0,False,True))
fp=[p for p in collect('جنگنده_2.glb',name='fighter',tagger=tg_canopy) if p['bb'][0]<0]
write('fighter.bin',fp,12000,mk(16,0,False,True))
