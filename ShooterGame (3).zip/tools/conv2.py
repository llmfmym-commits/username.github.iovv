exec(open('tools/conv.py').read().split('# gun:')[0])
def fm(L,ground):
    def f(parts,lo,hi):
        s=L/(hi-lo).max();c=(lo+hi)/2;off=np.array([c[0],lo[1] if ground else c[1],c[2]])
        for p in parts:p['P']=(p['P']-off)*s
    return f
for fn,out,tr,L,gr,root in [('تفنگ2.glb','gun2.bin',9000,.7,False,None),('تفنگ4.glb','gun4.bin',9000,.7,False,None),
 ('برج_.glb','tower.bin',12000,14,True,None),('2_ماشین_تریلی_جنگی.glb','trailer.bin',16000,12,True,None),('پک_گلوله.glb','ammo.bin',3000,.7,True,None),
 ('جت.glb','jet.bin',12000,14,False,None),('جنگنده_2.glb','fighter.bin',12000,16,False,None)]:
    ps=collect(fn,root=root,name=out[:-4],mx=512)
    if out=='fighter.bin':ps=[p for p in ps if p['bb'][0]<0]
    write(out,ps,tr,fm(L,gr))
