package com.qw.shooter
import android.app.Activity
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
class MainActivity:Activity(){
 lateinit var gv:GLSurfaceView
 override fun onCreate(s:Bundle?){super.onCreate(s)
  window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
  val g=G(this);gv=GLSurfaceView(this);gv.setEGLContextClientVersion(3);gv.setRenderer(g)
  val f=FrameLayout(this);f.addView(gv);f.addView(Hud(this,g));setContentView(f)
  window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE}
 override fun onPause(){super.onPause();gv.onPause()}
 override fun onResume(){super.onResume();gv.onResume()}
}
