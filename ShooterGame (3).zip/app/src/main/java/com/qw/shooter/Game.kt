package com.qw.shooter
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.graphics.Canvas
import android.graphics.Paint
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix as M
import android.view.MotionEvent
import android.view.View
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*
import kotlin.random.Random

// جهت‌ها: اگر مدلی عقب‌رو یا کج دیده شد فقط همین چهار عدد را تغییر بده
const val GUN_YAW=90f
const val SOL_YAW=0f
const val TANK_YAW=0f
const val HELI_YAW=0f
fun dg(r:Float)=r*57.29578f

object In{@Volatile var mx=0f;@Volatile var mz=0f;@Volatile var fire=false;@Volatile var reload=false;@Volatile var ldx=0f;@Volatile var ldy=0f;@Volatile var restart=false;@Volatile var sw=false;@Volatile var use=false;@Volatile var c=false;@Volatile var cam=false;@Volatile var jump=false;@Volatile var zoom=false;@Volatile var a=false;@Volatile var b=false}
class Part(val vb:Int,val ib:Int,val n:Int,val tex:Int,val col:FloatArray,val tag:Int=0,val pv:FloatArray=FloatArray(3))
class Mdl(val parts:List<Part>)
class En(val k:Int,var x:Float,var z:Float){var y=0f;var hp=1f;var t=0f;var dead=false;var dd=0f;var hit=0f;var cd=1.5f;var r=.45f;var y0=0f;var y1=1.8f;var v=0;var ang=0f;var kick=0f;var sp=2f;var a0=0f;var vy=0f;var walk=false;var sx=0f;var sz=0f}
class Pk(val x:Float,val z:Float)
class Fx(val x:Float,val y:Float,val z:Float,val s:Float,val f0:Int,val n:Int,val dur:Float){var t=0f}
class Ob(val x:Float,val z:Float,val yaw:Float,val k:Int,val r:Float)
class Tr(val a:FloatArray,val b:FloatArray,var l:Float,val w:Float=.012f)
class Veh(val kind:Int,var x:Float,var z:Float,var hy:Float){var y=0f;var p=0f;var rl=0f;var sp=0f;var k=0f;var c1=0f;var c2=0f;var ab=false;var eng=0f;var rot=0f;var wh=0f;var tur=0f;var el=0f;var rec=0f;var vx=0f;var vy=0f;var vz=0f;var th=0f;var tp=false}
class Hit(val e:En?,val t:Float)

class G(val c:Context):GLSurfaceView.Renderer{
 var prog=0;var white=0;var uMVP=0;var uM=0;var uC=0;var uE=0;var uCam=0;var uFog=0
 val tc=HashMap<String,Int>()
 val vs=ArrayList<Veh>();@Volatile var vi=-1;@Volatile var vkind=-1;@Volatile var canEnter=false;@Volatile var scope=false;@Volatile var c2f=1f;@Volatile var vname="";@Volatile var fsp=0f;@Volatile var falt=0f;@Volatile var fpt=0f;@Volatile var frl=0f;@Volatile var fhd=0f;@Volatile var rng=0f;@Volatile var sens=1f;@Volatile var fth=0f;@Volatile var adsT=0f;@Volatile var zoomOn=false;var fovCur=70f;var py=0f;var pvy=0f;var ldxS=0f;var cellX=999999;var cellZ=999999
 var aRot=0f;var aTail=0f;var aTur=0f;var aEl=0f;var aRec=0f;var aWh=0f;val eyeOff=Array(5){FloatArray(3)}
 val AR=floatArrayOf(.35f,.6f,.8f,.9f,.9f);val GY=floatArrayOf(0f,0f,1.6f,1.9f,1.3f);val VN=arrayOf("تانک","کامیون جنگی","هلیکوپتر","جت","جنگنده")
 lateinit var sky:Mdl;lateinit var quad:Mdl;val fxs=ArrayList<Fx>();@Volatile var menu=true;var uvx=0f;var uvy=0f;var uvw=1f;var uvh=1f;var uUV=0
 lateinit var gun:Mdl;lateinit var gl:List<Mdl>;lateinit var tower:Mdl;lateinit var trailer:Mdl;lateinit var ammoM:Mdl;lateinit var jet:Mdl;lateinit var fighter:Mdl;lateinit var sol:List<Mdl>;lateinit var tank:Mdl;lateinit var heli:Mdl;lateinit var bag:Mdl;lateinit var wire:Mdl;lateinit var cube:Mdl;lateinit var gnd:Mdl
 val en=ArrayList<En>();val obs=ArrayList<Ob>();val trs=ArrayList<Tr>()
 @Volatile var hp=100f;@Volatile var wi=0;val am=IntArray(3){30};val mg=intArrayOf(30,30,10);val rt=floatArrayOf(.11f,.08f,.55f);val dm=floatArrayOf(1f,.8f,4f);val gyw=floatArrayOf(90f,-90f,90f);val ammo:Int get()=am[wi];val mag:Int get()=mg[wi];var sw=0f;var jt=15f;val pks=ArrayList<Pk>();@Volatile var wave=0;@Volatile var score=0;@Volatile var over=false;@Volatile var dmgF=0f;@Volatile var hitM=0f;@Volatile var reloadT=0f
 var rld=false;var px=0f;var pz=0f;var yaw=0f;var pitch=0f;var cd=0f;var recoil=0f;var flash=0f;var bob=0f;var swx=0f;var swy=0f;var shake=0f;var tm=0f;var last=System.nanoTime();var w=1;var h=1;var waveT=0f
 val P=FloatArray(16);val V=FloatArray(16);val VP=FloatArray(16);val T=FloatArray(16);val MM=FloatArray(16)
 val Z3=floatArrayOf(0f,0f,0f);val DK=floatArrayOf(.3f,.3f,.3f,1f);val BK=floatArrayOf(0f,0f,0f,1f)

 fun sh(t:Int,s:String):Int{val i=GLES30.glCreateShader(t);GLES30.glShaderSource(i,s);GLES30.glCompileShader(i);return i}
 fun tex(n:String):Int=tc.getOrPut(n){val b=BitmapFactory.decodeStream(c.assets.open(if(n.contains('/'))n else "t/$n"));val a=IntArray(1);GLES30.glGenTextures(1,a,0)
  GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,a[0]);GLUtils.texImage2D(GLES30.GL_TEXTURE_2D,0,b,0);GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
  GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MIN_FILTER,GLES30.GL_LINEAR_MIPMAP_LINEAR);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MAG_FILTER,GLES30.GL_LINEAR);b.recycle();a[0]}
 fun mk(v:ByteBuffer,nv:Int,i:ByteBuffer,ni:Int,tx:Int,col:FloatArray,tag:Int=0,pv:FloatArray=FloatArray(3)):Part{val a=IntArray(2);GLES30.glGenBuffers(2,a,0)
  v.position(0);GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER,a[0]);GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER,nv*32,v,GLES30.GL_STATIC_DRAW)
  i.position(0);GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER,a[1]);GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER,ni*2,i,GLES30.GL_STATIC_DRAW);return Part(a[0],a[1],ni,tx,col,tag,pv)}
 fun load(f:String):Mdl{val b=ByteBuffer.wrap(c.assets.open("m/$f").readBytes()).order(ByteOrder.LITTLE_ENDIAN);val ps=ArrayList<Part>()
  repeat(b.int){val nv=b.int;val ni=b.int;val col=FloatArray(4){b.float};val ln=b.int;val nm=ByteArray(ln);b.get(nm);val tg=b.int;val pvv=FloatArray(3){b.float}
   val v=ByteBuffer.allocateDirect(nv*32).order(ByteOrder.nativeOrder());val vb=ByteArray(nv*32);b.get(vb);v.put(vb)
   val i=ByteBuffer.allocateDirect(ni*2).order(ByteOrder.nativeOrder());val ib=ByteArray(ni*2);b.get(ib);i.put(ib)
   ps.add(mk(v,nv,i,ni,if(ln>0)tex(String(nm)) else white,col,tg,pvv))}
  return Mdl(ps)}
 fun mesh(v:FloatArray,ix:ShortArray,tx:Int):Mdl{val vb=ByteBuffer.allocateDirect(v.size*4).order(ByteOrder.nativeOrder());vb.asFloatBuffer().put(v)
  val ib=ByteBuffer.allocateDirect(ix.size*2).order(ByteOrder.nativeOrder());ib.asShortBuffer().put(ix);return Mdl(listOf(mk(vb,v.size/8,ib,ix.size,tx,floatArrayOf(1f,1f,1f,1f))))}

 override fun onSurfaceCreated(g:GL10?,e:EGLConfig?){
  tc.clear()
  val vs="""#version 300 es
layout(location=0) in vec3 aP;layout(location=1) in vec3 aN;layout(location=2) in vec2 aT;uniform mat4 uMVP;uniform mat4 uM;uniform vec4 uUV;out vec2 vT;out vec3 vN;out vec3 vW;
void main(){vT=aT*uUV.zw+uUV.xy;vN=mat3(uM)*aN;vW=(uM*vec4(aP,1.)).xyz;gl_Position=uMVP*vec4(aP,1.);}"""
  val fs="""#version 300 es
precision mediump float;uniform sampler2D uS;uniform vec4 uC;uniform vec3 uE;uniform vec3 uCam;uniform float uFog;in vec2 vT;in vec3 vN;in vec3 vW;out vec4 o;
void main(){vec4 t=texture(uS,vT);vec3 n=normalize(vN);float l=uFog<-.5?1.:max(dot(n,normalize(vec3(.4,.8,.3))),0.)*.65+.5;vec3 c=t.rgb*uC.rgb*l+uE;float f=uFog>0.?clamp((length(vW-uCam)-40.)/110.,0.,1.):0.;o=vec4(mix(c,vec3(.66,.47,.30),f),uC.a*t.a);}"""
  prog=GLES30.glCreateProgram();GLES30.glAttachShader(prog,sh(GLES30.GL_VERTEX_SHADER,vs));GLES30.glAttachShader(prog,sh(GLES30.GL_FRAGMENT_SHADER,fs));GLES30.glLinkProgram(prog)
  uMVP=GLES30.glGetUniformLocation(prog,"uMVP");uM=GLES30.glGetUniformLocation(prog,"uM");uC=GLES30.glGetUniformLocation(prog,"uC");uE=GLES30.glGetUniformLocation(prog,"uE");uCam=GLES30.glGetUniformLocation(prog,"uCam");uFog=GLES30.glGetUniformLocation(prog,"uFog");uUV=GLES30.glGetUniformLocation(prog,"uUV")
  for(i in 0..2)GLES30.glEnableVertexAttribArray(i)
  val a=IntArray(1);GLES30.glGenTextures(1,a,0);white=a[0];GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,white)
  val wb=ByteBuffer.allocateDirect(4);wb.put(byteArrayOf(-1,-1,-1,-1));wb.position(0)
  GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D,0,GLES30.GL_RGBA,1,1,0,GLES30.GL_RGBA,GLES30.GL_UNSIGNED_BYTE,wb)
  GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MIN_FILTER,GLES30.GL_LINEAR);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MAG_FILTER,GLES30.GL_LINEAR)
  gun=load("gun.bin");sol=List(3){load("sol$it.bin")};tank=load("tank.bin");heli=load("heli.bin");bag=load("sandbag.bin");wire=load("wire.bin")
  gl=listOf(gun,load("gun2.bin"),load("gun4.bin"));tower=load("tower.bin");trailer=load("trailer.bin");ammoM=load("ammo.bin");jet=load("jet.bin");fighter=load("fighter.bin")
  for(pt in heli.parts)if(pt.tag==8){eyeOff[2][0]=pt.pv[0];eyeOff[2][1]=pt.pv[1]+.35f;eyeOff[2][2]=pt.pv[2]+.1f}
  for(pt in fighter.parts)if(pt.tag==8){eyeOff[4][0]=pt.pv[0];eyeOff[4][1]=pt.pv[1]+.25f;eyeOff[4][2]=pt.pv[2]}
  for(pt in tank.parts)if(pt.tag==3){tpv=pt.pv}
  eyeOff[0][1]=3.7f;eyeOff[1][1]=3.4f;eyeOff[3][1]=1.3f;eyeOff[3][2]=3.0f
  val cv=ArrayList<Float>();val ci=ArrayList<Short>()
  for(ax in 0..2)for(s in intArrayOf(-1,1)){val b=(ax+1)%3;val d=(ax+2)%3;val base=cv.size/8
   for(q in 0..3){val p=FloatArray(3);p[ax]=s.toFloat();p[b]=if(q and 1==0)-1f else 1f;p[d]=if(q and 2==0)-1f else 1f
    cv.addAll(listOf(p[0],p[1],p[2],if(ax==0)s.toFloat() else 0f,if(ax==1)s.toFloat() else 0f,if(ax==2)s.toFloat() else 0f,0f,0f))}
   for(k in intArrayOf(0,1,2,1,3,2))ci.add((base+k).toShort())}
  cube=mesh(cv.toFloatArray(),ci.toShortArray(),white)
  gnd=mesh(floatArrayOf(-150f,0f,-150f,0f,1f,0f,-37f,-37f,150f,0f,-150f,0f,1f,0f,37f,-37f,-150f,0f,150f,0f,1f,0f,-37f,37f,150f,0f,150f,0f,1f,0f,37f,37f),shortArrayOf(0,1,2,1,3,2),tex("ground.jpg"))
  GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_S,GLES30.GL_REPEAT)
  val sv=ArrayList<Float>();val si=ArrayList<Short>()
  for(i in 0..16)for(j in 0..32){val th=3.14159f*i/16f;val ph=6.28318f*j/32f;sv.addAll(listOf(sin(th)*cos(ph),cos(th),sin(th)*sin(ph),0f,1f,0f,j/32f,i/16f))}
  for(i in 0 until 16)for(j in 0 until 32){val a=i*33+j;for(k in intArrayOf(a,a+33,a+1,a+1,a+33,a+34))si.add(k.toShort())}
  sky=mesh(sv.toFloatArray(),si.toShortArray(),tex("ui/sky.jpg"))
  quad=mesh(floatArrayOf(-.5f,-.5f,0f,0f,0f,1f,0f,1f,.5f,-.5f,0f,0f,0f,1f,1f,1f,-.5f,.5f,0f,0f,0f,1f,0f,0f,.5f,.5f,0f,0f,0f,1f,1f,0f),shortArrayOf(0,1,2,1,3,2),tex("ui/exp.png"));quad.parts[0].col[3]=.98f
  obs.clear();val rn=Random(7)
  if(false)  repeat(18){val a2=rn.nextFloat()*6.283f;val r=9f+rn.nextFloat()*52f;val k=if(it%3==2)1 else 0;obs.add(Ob(sin(a2)*r,cos(a2)*r,rn.nextFloat()*360f,k,if(k==0)1.6f else 2.4f))}
  rebuildObs(true)
  reset()}
 override fun onSurfaceChanged(g:GL10?,ww:Int,hh:Int){GLES30.glViewport(0,0,ww,hh);w=ww;h=hh}


 fun vr(v:Veh)=when(v.kind){0->3.4f;1->5f;2->3.6f;3->3.4f;else->3.8f}
 fun vyaw(v:Veh)=if(v.kind==1)-90f-dg(v.hy) else 180f-dg(v.hy)
 fun cast(ox:Float,oy:Float,oz:Float,dx:Float,dy:Float,dz:Float,mx:Float):Hit{var bt=mx;var be:En?=null
  if(dy<-1e-4f){val tg=-oy/dy;if(tg<bt)bt=tg}
  for(e in en){if(e.dead)continue;val qx=ox-e.x;val qz=oz-e.z;val a=dx*dx+dz*dz;if(a<1e-6f)continue
   val b=2f*(qx*dx+qz*dz);val cc=qx*qx+qz*qz-e.r*e.r;val ds=b*b-4f*a*cc;if(ds<0f)continue
   val t=(-b-sqrt(ds))/(2f*a);if(t<0f||t>=bt)continue;val yy=oy+dy*t;if(yy<e.y0||yy>e.y1)continue;bt=t;be=e}
  return Hit(be,bt)}
 fun dmgEn(e:En,d:Float){e.hp-=d;e.hit=.15f;hitM=.2f;if(e.hp<=0f&&!e.dead){e.dead=true;e.dd=0f
   when(e.k){0->boom(e.x,.9f,e.z,2.4f,48,8,.5f);1->boom(e.x,2f,e.z,11f,0,32,1.8f);else->boom(e.x,e.y,e.z,10f,0,32,1.6f)};score+=when(e.k){0->10;1->100;2->150;else->200}}}
 fun splash(x:Float,y:Float,z:Float,dmg:Float,rad:Float){for(e in en){if(e.dead)continue;val d=hypot(e.x-x,e.z-z);if(d<rad+e.r&&y>e.y0-rad&&y<e.y1+rad)dmgEn(e,dmg*(1f-min(d/(rad+e.r),1f)*.6f))}}
 fun fireV(ox:Float,oy:Float,oz:Float,tx:Float,ty:Float,tz:Float,dmg:Float,rad:Float,sc:Float,w:Float){
  val dx=tx-ox;val dy=ty-oy;val dz=tz-oz;val ln=max(sqrt(dx*dx+dy*dy+dz*dz),.01f);val ux=dx/ln;val uy=dy/ln;val uz=dz/ln
  val h=cast(ox,oy,oz,ux,uy,uz,ln+60f);val qx=ox+ux*h.t;val qy=oy+uy*h.t;val qz=oz+uz*h.t
  trs.add(Tr(floatArrayOf(ox,oy,oz),floatArrayOf(qx,qy,qz),.07f,w))
  if(sc>=3f)boom(qx,qy+sc*.3f,qz,sc,0,32,.9f) else boom(qx,qy,qz,sc,64,8,.2f)
  splash(qx,qy,qz,dmg,rad)}
fun animVeh(v:Veh,occ:Boolean,dt:Float){
  v.eng+=((if(occ)1f else 0f)-v.eng)*min(dt/(if(occ)2.2f else 3.5f),1f);v.rot=(v.rot+v.eng*2200f*dt)%3600f
  if(v.kind<=1)v.wh=(v.wh+v.sp*dt/.55f*57.3f)%3600f
  if(v.kind==0&&occ){var d=v.hy-yaw;d=atan2(sin(d),cos(d));val df=atan2(sin(d-v.tur),cos(d-v.tur));v.tur+=df.coerceIn(-1.2f*dt,1.2f*dt)
   v.el+=(pitch.coerceIn(-.12f,.38f)-v.el).coerceIn(-.6f*dt,.6f*dt)}}
 fun camEye(v:Veh,a:Float,b:Float,c:Float):FloatArray{
  if(!v.tp){val o=eyeOff[v.kind];val fwx=sin(v.hy);val fwz=-cos(v.hy);val lx=-cos(v.hy);val lz=-sin(v.hy);return floatArrayOf(v.x+fwx*o[2]+lx*o[0],v.y+o[1],v.z+fwz*o[2]+lz*o[0])}
  val D=when(v.kind){0->11f;1->10f;else->20f};val cy=v.y+(if(v.kind==2)0f else 2.6f);return floatArrayOf(v.x-a*D,max(cy-b*D,1f),v.z-c*D)}
 fun vehUpd(dt:Float){val v=vs[vi];val ax=In.mx;val az=In.mz
  v.c1=max(0f,v.c1-dt);v.c2=max(0f,v.c2-dt);v.k=max(0f,v.k-dt*3f)
  when(v.kind){
   0,1->{val mxs=if(v.kind==0)8f else 14f;v.hy+=ax*(if(v.kind==0)1.1f else 1.5f)*dt*(if(v.sp<-.5f)-1f else 1f)
    v.sp+=(-az*mxs-v.sp)*min(dt*2.5f,1f);v.x+=sin(v.hy)*v.sp*dt;v.z-=cos(v.hy)*v.sp*dt
    for(o in obs){val dx=v.x-o.x;val dz=v.z-o.z;val d=hypot(dx,dz);val m=o.r+vr(v)*.6f;if(d<m&&d>1e-3f){v.x=o.x+dx/d*m;v.z=o.z+dz/d*m;v.sp*=.5f}}
    v.y=GY[v.kind]}
   2->{val dyw=atan2(sin(yaw-v.hy),cos(yaw-v.hy));v.hy+=dyw.coerceIn(-1.8f*dt,1.8f*dt)
    val onG=v.y<=GY[2]+.05f;val ef=if(v.eng>.85f)1f else 0f;val hf=sin(v.hy);val hz=-cos(v.hy);val hrx=cos(v.hy);val hrz=sin(v.hy);val sp2=if(onG)0f else 26f*ef
    v.vx+=((hrx*ax-hf*az)*sp2-v.vx).coerceIn(-9f*dt,9f*dt);v.vz+=((hrz*ax-hz*az)*sp2-v.vz).coerceIn(-9f*dt,9f*dt)
    if(ax==0f&&az==0f){v.vx*=1f-.9f*dt;v.vz*=1f-.9f*dt}
    v.vy+=(((if(In.a)7f else 0f)-(if(In.b)6f else 0f))*ef-v.vy).coerceIn(-5f*dt,5f*dt)
    v.x+=v.vx*dt;v.z+=v.vz*dt;v.y+=v.vy*dt
    if(v.y<=GY[2]){if(v.vy<-6.5f)hurt(25f);v.y=GY[2];if(v.vy<0f)v.vy=0f}
    if(v.y>110f){v.y=110f;if(v.vy>0f)v.vy=0f}
    val fwdV=v.vx*hf+v.vz*hz;val sideV=v.vx*hrx+v.vz*hrz
    v.p+=(-fwdV/26f*.38f-v.p)*min(dt*3f,1f);v.rl+=(sideV/26f*.35f-v.rl)*min(dt*3f,1f)}
   else->{val fi=v.kind==4;val g0=GY[v.kind];val onG=v.y<=g0+.05f;v.ab=In.a
    v.th=(v.th+((if(In.b)1f else 0f)-(if(In.c)1f else 0f))*.5f*dt).coerceIn(0f,1f)
    val tgt=if(onG)v.th*(if(fi)78f else 72f)+(if(v.ab)15f else 0f) else 38f+v.th*(if(fi)82f else 68f)+(if(v.ab)38f else 0f)
    val acc=if(onG&&az>.3f)35f else 22f;v.sp+=(tgt-v.sp).coerceIn(-acc*dt,acc*dt)
    v.rl+=((if(onG)0f else ax*1.1f)-v.rl)*min(dt*3f,1f);v.hy+=sin(v.rl)*1.3f*dt+(if(onG)ax*.6f*dt*min(v.sp/20f,1f) else 0f)+ldxS*.0022f
    if(!onG||v.sp>38f)v.p+=az*.9f*dt
    if(!onG&&v.sp<32f)v.p-=.7f*dt
    if(!onG&&abs(az)<.1f)v.p*=1f-.25f*dt
    if(onG&&v.p<0f)v.p=0f;v.p=v.p.coerceIn(-1.2f,1.2f)
    val c=cos(v.p);v.x+=sin(v.hy)*c*v.sp*dt;v.y+=sin(v.p)*v.sp*dt;v.z-=cos(v.hy)*c*v.sp*dt
    if(v.y<=g0){if(v.p<-.3f&&v.sp>30f&&!onG){boom(v.x,3f,v.z,12f,0,32,1.8f);hurt(999f)};v.y=g0;if(v.p<0f)v.p=0f}
    if(v.y>130f){v.y=130f;if(v.p>0f)v.p=0f}
        fth=v.th;fsp=v.sp*3.6f;falt=v.y-g0;fpt=v.p;frl=v.rl;fhd=((dg(v.hy)%360f)+360f)%360f}}
  px=v.x;pz=v.z
  val lfx=sin(yaw)*cos(pitch);val lfy=sin(pitch);val lfz=-cos(yaw)*cos(pitch)
  val ox:Float;val oy:Float;val oz:Float;val tx:Float;val ty:Float;val tz:Float
  if(v.kind>=3){val c=cos(v.p);val jx=sin(v.hy)*c;val jy=sin(v.p);val jz=-cos(v.hy)*c;ox=v.x+jx*6f;oy=v.y+jy*6f;oz=v.z+jz*6f;tx=v.x+jx*500f;ty=v.y+jy*500f;tz=v.z+jz*500f}
  else{val ce=camEye(v,lfx,lfy,lfz);val h=cast(ce[0],ce[1],ce[2],lfx,lfy,lfz,400f);tx=ce[0]+lfx*h.t;ty=ce[1]+lfy*h.t;tz=ce[2]+lfz*h.t;rng=h.t
   if(v.kind==2){ox=v.x+lfx*3f;oy=v.y-.6f;oz=v.z+lfz*3f}else if(v.kind==0){ox=v.x+sin(v.hy-v.tur)*4.5f;oy=v.y+2.7f+sin(v.el)*4.5f;oz=v.z-cos(v.hy-v.tur)*4.5f}else{ox=v.x+sin(v.hy)*3.5f;oy=v.y+2.7f;oz=v.z-cos(v.hy)*3.5f}}
  var dd=v.hy-yaw;dd=atan2(sin(dd),cos(dd));val aligned=v.kind!=0||abs(atan2(sin(dd-v.tur),cos(dd-v.tur)))<.15f
  if(In.fire&&v.c1<=0f&&aligned)when(v.kind){
   0->{v.c1=2.2f;v.k=1f;shake+=.08f;fireV(ox,oy,oz,tx,ty,tz,14f,7f,7f,.06f)}
   1->{v.c1=.9f;shake+=.02f;fireV(ox,oy,oz,tx,ty,tz,6f,4f,4f,.04f)}
   2->{v.c1=.06f;fireV(ox,oy,oz,tx,ty,tz,.7f,.8f,.6f,.01f)}
   else->{v.c1=.05f;fireV(ox,oy,oz,tx,ty,tz,.7f,.8f,.6f,.01f)}}
  if(In.reload){In.reload=false
   when(v.kind){0->scope=!scope
    1->if(v.c2<=0f){v.c2=4f;fireV(ox,oy,oz,tx,ty,tz,16f,9f,9f,.08f)}
    2->if(v.c2<=0f){v.c2=1.1f;fireV(ox,oy,oz,tx,ty,tz,8f,5f,5f,.06f)}
    else->if(v.c2<=0f){v.c2=if(v.kind==4)2f else 2.5f;fireV(ox,oy,oz,tx,ty,tz,15f,8f,8f,.07f)}}}
  c2f=when(v.kind){1->1f-v.c2/4f;2->1f-v.c2/1.1f;3->1f-v.c2/2.5f;4->1f-v.c2/2f;else->1f}}
 fun boom(x:Float,y:Float,z:Float,sc:Float,f0:Int,n:Int,dur:Float){fxs.add(Fx(x,y,z,sc,f0,n,dur))}
fun hsh(a:Int,b:Int,s:Int):Float{var h=a*374761393+b*668265263+s*1274126177;h=(h xor (h ushr 13))*1274126177;h=h xor (h ushr 16);return (h and 0xFFFFFF)/16777216f}
 fun rebuildObs(force:Boolean){val cx=floor(px/40f).toInt();val cz=floor(pz/40f).toInt();if(!force&&cx==cellX&&cz==cellZ)return;cellX=cx;cellZ=cz;obs.clear()
  for(i in cx-5..cx+5)for(j in cz-5..cz+5){val r0=hsh(i,j,1);val n=if(r0<.35f)0 else if(r0<.8f)1 else 2
   for(k in 0 until n){val x=(i+hsh(i,j,2+k*5))*40f;val z=(j+hsh(i,j,3+k*5))*40f;if(hypot(x,z)<60f)continue
    val t=hsh(i,j,4+k*5);val kind=if(t<.7f)0 else if(t<.965f)1 else if(t<.98f)2 else 3
    obs.add(Ob(x,z,hsh(i,j,5+k*5)*360f,kind,when(kind){0->1.6f;1->2.4f;2->2.8f;else->5.5f}))}}}
 fun reset(){px=0f;pz=0f;py=0f;pvy=0f;rebuildObs(true);vs.clear();vs.add(Veh(0,-12f,-14f,0f));vs.add(Veh(1,12f,-14f,0f));vs.add(Veh(2,-28f,-32f,0f));vs.add(Veh(3,28f,-32f,0f));vs.add(Veh(4,0f,-46f,0f));for(v in vs)v.y=GY[v.kind];vi=-1;scope=false
  fxs.clear();en.clear();trs.clear();hp=100f;for(i in 0..2)am[i]=mg[i];wi=0;sw=0f;jt=15f;pks.clear();wave=0;score=0;over=false;px=0f;pz=0f;yaw=0f;pitch=0f;rld=false;reloadT=0f;waveT=0f;nextWave()}
 fun nextWave(){wave++
  repeat(2){val a=Random.nextFloat()*6.283f;val r=8f+Random.nextFloat()*42f;pks.add(Pk(px+sin(a)*r,pz+cos(a)*r))}
  fun pos():FloatArray{val a=Random.nextFloat()*6.283f;val r=38f+Random.nextFloat()*17f;return floatArrayOf(px+sin(a)*r,pz+cos(a)*r)}
  repeat(3+wave*2){val p=pos();en.add(En(0,p[0],p[1]).apply{hp=3f+wave*.3f;sp=min(1.8f+wave*.15f,4.2f);a0=9f+Random.nextFloat()*7f;v=Random.nextInt(3)})}
  if(wave%3==0){val p=pos();en.add(En(1,p[0],p[1]).apply{hp=30f;r=2.6f;y1=3f;cd=3f})}
  if(wave>=4&&wave%2==0){en.add(En(2,px,pz+42f).apply{hp=14f;r=3.2f;y=17f;cd=3f;a0=Random.nextFloat()*6f})}}
 fun spawnJet(){val a=Random.nextFloat()*6.283f;val e=En(3+Random.nextInt(2),px+sin(a)*125f,pz+cos(a)*125f);val dx=px+(Random.nextFloat()-.5f)*60f-e.x;val dz=pz+(Random.nextFloat()-.5f)*60f-e.z;val d=hypot(dx,dz)
  e.sx=dx/d*48f;e.sz=dz/d*48f;e.y=38f+Random.nextFloat()*10f;e.hp=6f;e.r=5f;en.add(e)}
 fun hurt(d0:Float){val d=if(vi>=0)d0*AR[vs[vi].kind] else d0;hp-=d;dmgF=.4f;shake=.06f;if(hp<=0f){hp=0f;over=true}}
 fun push(e:En){for(o in obs){val dx=e.x-o.x;val dz=e.z-o.z;val d=hypot(dx,dz);val m=o.r+e.r+.2f;if(d<m&&d>1e-3f){e.x=o.x+dx/d*m;e.z=o.z+dz/d*m}}}
 fun shoot(){pitch+=.004f*(if(zoomOn).5f else 1f);yaw+=(Random.nextFloat()-.5f)*.003f;recoil=1f;flash=.05f;shake+=.015f
  val cp=cos(pitch);val fx=sin(yaw)*cp;val fy=sin(pitch);val fz=-cos(yaw)*cp;var bt=60f;var be:En?=null
  for(e in en){if(e.dead)continue;val ox=px-e.x;val oz=pz-e.z;val a=fx*fx+fz*fz;if(a<1e-6f)continue
   val b=2f*(ox*fx+oz*fz);val cc=ox*ox+oz*oz-e.r*e.r;val ds=b*b-4f*a*cc;if(ds<0f)continue
   val t=(-b-sqrt(ds))/(2f*a);if(t<0f||t>=bt)continue;val yy=1.6f+py+fy*t;if(yy<e.y0||yy>e.y1)continue;bt=t;be=e}
  trs.add(Tr(floatArrayOf(px+cos(yaw)*.2f+fx*.6f,1.45f+py+fy*.6f,pz+sin(yaw)*.2f+fz*.6f),floatArrayOf(px+fx*bt,1.6f+py+fy*bt,pz+fz*bt),.05f))
  be?.let{boom(px+fx*bt,1.6f+py+fy*bt,pz+fz*bt,.8f,64,8,.25f);val hs=it.k==0&&1.6f+py+fy*bt>it.y0+1.45f;it.hp-=dm[wi]*(if(hs)2f else 1f);it.hit=.15f;hitM=.2f
   if(it.hp<=0f){it.dead=true;it.dd=0f;when(it.k){0->boom(it.x,.9f,it.z,2.4f,48,8,.5f);1->boom(it.x,2f,it.z,11f,0,32,1.8f);else->boom(it.x,it.y,it.z,10f,0,32,1.6f)};score+=when(it.k){0->10;1->100;2->150;else->200}}}}

 fun upd(dt:Float){tm+=dt
  if(menu){In.ldx=0f;In.ldy=0f;if(In.restart){In.restart=false;menu=false;reset()};return}
  if(In.restart){In.restart=false;if(over)reset()}
  dmgF=max(0f,dmgF-dt);hitM=max(0f,hitM-dt);shake=max(0f,shake-dt*.3f)
  for(i in trs.indices.reversed()){trs[i].l-=dt;if(trs[i].l<=0f)trs.removeAt(i)}
  for(i in fxs.indices.reversed()){fxs[i].t+=dt;if(fxs[i].t>fxs[i].dur)fxs.removeAt(i)}
  val lx=In.ldx;val ly=In.ldy;In.ldx=0f;In.ldy=0f
  if(over)return
  ldxS=lx;val ks=sens*fovCur/70f;yaw+=lx*.0045f*ks;pitch=(pitch-ly*.004f*ks).coerceIn(-1.2f,1.2f)
  if(In.zoom){In.zoom=false;if(vi<0)zoomOn=!zoomOn};if(vi>=0)zoomOn=false
  if(In.cam){In.cam=false;if(vi>=0)vs[vi].tp=!vs[vi].tp}
  val fovT=if(vi>=0){if(scope&&vs[vi].kind==0)28f else 70f}else if(zoomOn)(if(wi==2)20f else 48f) else 70f
  fovCur+=(fovT-fovCur)*min(dt*9f,1f);adsT+=((if(zoomOn)1f else 0f)-adsT)*min(dt*9f,1f)
  if(In.jump){In.jump=false;if(vi<0&&py<=0f)pvy=4.6f}
  if(vi<0){pvy-=12f*dt;py+=pvy*dt;if(py<=0f){py=0f;if(pvy<0f)pvy=0f}}else{py=0f;pvy=0f}
  val k=min(dt*10f,1f);swx+=((-lx*.0009f).coerceIn(-.04f,.04f)-swx)*k;swy+=((ly*.0007f).coerceIn(-.03f,.03f)-swy)*k
  if(vi<0){val fx=sin(yaw);val fz=-cos(yaw);val rx=cos(yaw);val rz=sin(yaw)
  px+=(rx*In.mx-fx*In.mz)*5f*dt;pz+=(rz*In.mx-fz*In.mz)*5f*dt
  for(o in obs){val dx=px-o.x;val dz=pz-o.z;val d=hypot(dx,dz);val m=o.r+.4f;if(d<m&&d>1e-3f){px=o.x+dx/d*m;pz=o.z+dz/d*m}}
    bob+=dt*min(1f,hypot(In.mx,In.mz))*9f
  for(v in vs){val dx=px-v.x;val dz=pz-v.z;val d=hypot(dx,dz);val m=vr(v)+.4f;if(d<m&&d>1e-3f){px=v.x+dx/d*m;pz=v.z+dz/d*m}}}
  sw=max(0f,sw-dt*4f);if(In.sw){In.sw=false;wi=(wi+1)%3;rld=false;reloadT=0f;sw=1f}
  jt-=dt;if(jt<=0f&&wave>=2){jt=28f;spawnJet()}
  val pr=ArrayList<Pk>();for(q in pks)if(hypot(px-q.x,pz-q.z)<1.8f){hp=min(100f,hp+25f);for(i in 0..2)am[i]=mg[i];rld=false;pr.add(q)};pks.removeAll(pr)
  cd-=dt;reloadT=max(0f,reloadT-dt);recoil=max(0f,recoil-dt*9f);flash=max(0f,flash-dt)
  if(rld&&reloadT<=0f){am[wi]=mg[wi];rld=false}
  if(vi<0){if(In.reload&&am[wi]<mg[wi]&&!rld){reloadT=1.8f;rld=true};In.reload=false}
  if(vi<0&&In.fire&&cd<=0f&&!rld){if(am[wi]>0){shoot();cd=rt[wi];am[wi]--}else{reloadT=1.8f;rld=true}}
  for(i in vs.indices)animVeh(vs[i],i==vi,dt)
  rebuildObs(false)
  vkind=if(vi>=0)vs[vi].kind else -1
  if(In.use){In.use=false
   if(vi<0){var bi=-1;var bd=1e9f;for(i in vs.indices){val d=hypot(px-vs[i].x,pz-vs[i].z);if(d<vr(vs[i])+4f&&d<bd){bd=d;bi=i}}
    if(bi>=0){vi=bi;scope=false;vname=VN[vs[bi].kind];yaw=vs[bi].hy;pitch=0f;vs[bi].sp=0f;vs[bi].c1=.3f;vs[bi].tp=vs[bi].kind==1}}
   else{val v=vs[vi];if(v.kind<2||(v.y<=GY[v.kind]+.3f&&v.sp<22f)){px=v.x+cos(v.hy)*(vr(v)+1.5f);pz=v.z+sin(v.hy)*(vr(v)+1.5f);vi=-1;scope=false;v.sp=0f;v.ab=false;v.vx=0f;v.vz=0f;v.vy=0f;v.th=0f;In.fire=false}}}
  if(vi>=0)vehUpd(dt) else canEnter=vs.any{hypot(px-it.x,pz-it.z)<vr(it)+4f}
  val rm=ArrayList<En>()
  for(e in en){e.t+=dt;e.hit-=dt;e.kick=max(0f,e.kick-dt*4f)
   if(e.dead){e.dd+=dt;if(e.k>=2&&e.y>0f){e.vy+=dt*9f;e.y=max(0f,e.y-e.vy*dt);e.ang+=dt*6f;if(e.y<=0f)boom(e.x,2f,e.z,12f,0,32,1.8f)};if(e.dd>if(e.k==0)3f else 6f)rm.add(e);continue}
   val dx=px-e.x;val dz=pz-e.z;val d=max(hypot(dx,dz),.01f)
   when(e.k){
    0->{e.ang=atan2(dx,dz);e.walk=d>e.a0
     if(e.walk){e.x+=dx/d*e.sp*dt;e.z+=dz/d*e.sp*dt;push(e)}
     else{e.cd-=dt;if(e.cd<=0f){e.cd=1.1f+Random.nextFloat()*.8f;e.kick=1f;trs.add(Tr(floatArrayOf(e.x,1.3f,e.z),floatArrayOf(px,1.4f,pz),.07f));if(Random.nextFloat()<.4f)hurt(5f)}}}
    1->{e.ang=atan2(dx,dz);if(d>28f){e.x+=dx/d*1.6f*dt;e.z+=dz/d*1.6f*dt;push(e)}
     e.cd-=dt;if(e.cd<=0f){e.cd=3.5f;e.kick=1f;trs.add(Tr(floatArrayOf(e.x,2.6f,e.z),floatArrayOf(px,1.2f,pz),.2f));if(Random.nextFloat()<.7f)hurt(18f)}}
    2->{e.a0+=dt*.3f;val nx=px+sin(e.a0)*42f;val nz=pz+cos(e.a0)*42f;val vx=nx-e.x;val vz=nz-e.z;if(abs(vx)+abs(vz)>1e-4f)e.ang=atan2(vx,vz)
     e.x=nx;e.z=nz;e.y=17f+sin(e.t*1.3f)*1.5f;e.y0=e.y-1.5f;e.y1=e.y+2.5f
     e.cd-=dt;if(e.cd<=0f){e.cd=4f;e.kick=1f;trs.add(Tr(floatArrayOf(e.x,e.y,e.z),floatArrayOf(px,1.3f,pz),.12f));if(Random.nextFloat()<.6f)hurt(10f)}}
    else->{e.x+=e.sx*dt;e.z+=e.sz*dt;e.ang=atan2(e.sx,e.sz);e.y0=e.y-2f;e.y1=e.y+2f;if(e.t>3f&&hypot(e.x-px,e.z-pz)>150f)rm.add(e)}}}
  en.removeAll(rm)
  if(en.none{!it.dead&&it.k<3}){waveT+=dt;if(waveT>2.5f){waveT=0f;nextWave()}}}

 val PM=FloatArray(16);val Q=FloatArray(16)
 fun rotAt(m:FloatArray,deg:Float,ax:Float,ay:Float,az:Float,pv:FloatArray){M.translateM(m,0,pv[0],pv[1],pv[2]);M.rotateM(m,0,deg,ax,ay,az);M.translateM(m,0,-pv[0],-pv[1],-pv[2])}
 fun partMat(p:Part,mm:FloatArray):FloatArray{System.arraycopy(mm,0,PM,0,16)
  when(p.tag){1->rotAt(PM,aRot,0f,1f,0f,p.pv);2->rotAt(PM,aTail,1f,0f,0f,p.pv);5->rotAt(PM,aWh,1f,0f,0f,p.pv)
   3->rotAt(PM,aTur,0f,1f,0f,p.pv)
   4,6->{rotAt(PM,aTur,0f,1f,0f,tpv);rotAt(PM,aEl,1f,0f,0f,p.pv);if(p.tag==6)M.translateM(PM,0,0f,0f,-aRec)}}
  return PM}
 var tpv=floatArrayOf(0f,1.36f,-1.28f)
 fun draw(m:Mdl,mm:FloatArray,vp:FloatArray,tint:FloatArray?=null,em:FloatArray?=null,fog:Float=1f){
  M.multiplyMM(MM,0,vp,0,mm,0);GLES30.glUniformMatrix4fv(uMVP,1,false,MM,0);GLES30.glUniformMatrix4fv(uM,1,false,mm,0)
  val e=em?:Z3;GLES30.glUniform3f(uE,e[0],e[1],e[2]);GLES30.glUniform1f(uFog,fog);GLES30.glUniform4f(uUV,uvx,uvy,uvw,uvh)
  val t=tint?:floatArrayOf(1f,1f,1f,1f)
  for(pass in 0..1){if(pass==1){GLES30.glEnable(GLES30.GL_BLEND);GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA,GLES30.GL_ONE_MINUS_SRC_ALPHA);GLES30.glDepthMask(false);M.multiplyMM(MM,0,vp,0,mm,0);GLES30.glUniformMatrix4fv(uMVP,1,false,MM,0);GLES30.glUniformMatrix4fv(uM,1,false,mm,0)}
   var dirty=false
   for(p in m.parts){if((p.col[3]<.99f)!=(pass==1))continue
    if(p.tag in 1..6){val pmx=partMat(p,mm);M.multiplyMM(Q,0,vp,0,pmx,0);GLES30.glUniformMatrix4fv(uMVP,1,false,Q,0);GLES30.glUniformMatrix4fv(uM,1,false,pmx,0);dirty=true}
    else if(dirty){M.multiplyMM(MM,0,vp,0,mm,0);GLES30.glUniformMatrix4fv(uMVP,1,false,MM,0);GLES30.glUniformMatrix4fv(uM,1,false,mm,0);dirty=false}
    GLES30.glUniform4f(uC,p.col[0]*t[0],p.col[1]*t[1],p.col[2]*t[2],p.col[3]*t[3])
    GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,p.tex);GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER,p.vb);GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER,p.ib)
    GLES30.glVertexAttribPointer(0,3,GLES30.GL_FLOAT,false,32,0);GLES30.glVertexAttribPointer(1,3,GLES30.GL_FLOAT,false,32,12);GLES30.glVertexAttribPointer(2,2,GLES30.GL_FLOAT,false,32,24)
    GLES30.glDrawElements(GLES30.GL_TRIANGLES,p.n,GLES30.GL_UNSIGNED_SHORT,0)}}
  GLES30.glDisable(GLES30.GL_BLEND);GLES30.glDepthMask(true)}

 override fun onDrawFrame(g:GL10?){
  val now=System.nanoTime();val dt=min((now-last)/1e9f,.05f);last=now;upd(dt)
  if(menu){GLES30.glClearColor(0f,0f,0f,1f);GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);return}
  GLES30.glClearColor(.66f,.47f,.30f,1f);GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT);GLES30.glEnable(GLES30.GL_DEPTH_TEST);GLES30.glUseProgram(prog)
  val asp=w.toFloat()/h;val cp=cos(pitch);val sx=(Random.nextFloat()-.5f)*shake;val sy=(Random.nextFloat()-.5f)*shake
  var ex=px+sx;var ey=1.6f+py+sy+if(over)-.9f else 0f;var ez=pz;var tx=px+sin(yaw)*cp;var ty=ey+sin(pitch);var tz=pz-cos(yaw)*cp;var fov=fovCur;var ux=0f;var uy=1f;var uz=0f
  if(vi>=0){val v=vs[vi]
   if(v.kind>=3){val c=cos(v.p);val jx=sin(v.hy)*c;val jy=sin(v.p);val jz=-cos(v.hy)*c
    if(v.tp){ex=v.x-jx*15f;ey=max(v.y-jy*15f+4f,1.5f);ez=v.z-jz*15f}else{val o=eyeOff[v.kind];ex=v.x+jx*o[2];ey=v.y+jy*o[2]+o[1];ez=v.z+jz*o[2]}
    tx=ex+jx*40f;ty=ey+jy*40f;tz=ez+jz*40f;ux=cos(v.hy)*sin(v.rl);uy=cos(v.rl);uz=sin(v.hy)*sin(v.rl)}
   else{val ce=camEye(v,sin(yaw)*cp,sin(pitch),-cos(yaw)*cp);ex=ce[0];ey=ce[1];ez=ce[2];tx=ex+sin(yaw)*cp;ty=ey+sin(pitch);tz=ez-cos(yaw)*cp}}
  M.setLookAtM(V,0,ex,ey,ez,tx,ty,tz,ux,uy,uz);M.perspectiveM(P,0,fov,asp,.1f,300f);M.multiplyMM(VP,0,P,0,V,0)
  GLES30.glUniform3f(uCam,ex,ey,ez)
  GLES30.glDepthMask(false);M.setIdentityM(T,0);M.translateM(T,0,ex,ey,ez);M.scaleM(T,0,190f,190f,190f);draw(sky,T,VP,null,null,-1f);GLES30.glDepthMask(true)
  M.setIdentityM(T,0);M.translateM(T,0,floor(ex/4f)*4f,0f,floor(ez/4f)*4f);draw(gnd,T,VP)
  for(o in obs){if(hypot(o.x-ex,o.z-ez)>140f)continue;M.setIdentityM(T,0);M.translateM(T,0,o.x,0f,o.z);M.rotateM(T,0,o.yaw,0f,1f,0f)
   when(o.k){1->draw(wire,T,VP);2->draw(tower,T,VP);3->draw(trailer,T,VP);else->for(i in -1..1){val t2=T.copyOf();M.translateM(t2,0,i*.95f,0f,0f);draw(bag,t2,VP)}}}
  for(q in pks){M.setIdentityM(T,0);M.translateM(T,0,q.x,.35f+sin(tm*3f)*.1f,q.z);M.rotateM(T,0,tm*90f,0f,1f,0f);draw(ammoM,T,VP,null,floatArrayOf(.15f,.12f,0f))}
  for(i in vs.indices){val v=vs[i];if(i==vi&&(scope||(!v.tp&&v.kind!=0)))continue
   M.setIdentityM(T,0);M.translateM(T,0,v.x,v.y,v.z);M.rotateM(T,0,vyaw(v),0f,1f,0f)
   aRot=v.rot;aTail=v.rot*1.9f;aTur=dg(v.tur);aEl=-dg(v.el);aRec=v.k*.45f;aWh=v.wh
   if(v.kind>=2){M.rotateM(T,0,-dg(v.p),1f,0f,0f);M.rotateM(T,0,dg(v.rl),0f,0f,1f)}
   draw(when(v.kind){0->tank;1->trailer;2->heli;3->jet;else->fighter},T,VP)}
  for(e in en){M.setIdentityM(T,0);val em=floatArrayOf(max(e.hit,0f)*4f,0f,0f);val tn=if(e.dead)DK else null
   when(e.k){
    0->{val wk=if(e.walk&&!e.dead)abs(sin(e.t*9f))*.07f else 0f
     M.translateM(T,0,e.x,wk,e.z);M.rotateM(T,0,dg(e.ang)+SOL_YAW,0f,1f,0f)
     if(e.dead)M.rotateM(T,0,-min(e.dd/.5f,1f)*88f,1f,0f,0f)
     else{M.rotateM(T,0,if(e.walk)sin(e.t*9f)*4f else 0f,0f,0f,1f);M.rotateM(T,0,(if(e.walk)7f else 0f)-e.kick*9f,1f,0f,0f)}
     draw(sol[e.v],T,VP,tn,em)}
    1->{aTur=0f;aEl=0f;aRec=e.kick*.45f;aWh=(e.t*200f)%3600f;M.translateM(T,0,e.x,if(e.dead)-min(e.dd*.15f,1.2f) else 0f,e.z);M.rotateM(T,0,dg(e.ang)+TANK_YAW,0f,1f,0f);M.translateM(T,0,0f,0f,-e.kick*.35f)
     if(!e.dead){M.rotateM(T,0,sin(e.t*1.7f)*.5f,0f,0f,1f);M.rotateM(T,0,sin(e.t*2.3f)*.25f,0f,0f,1f)}
     draw(tank,T,VP,tn,em)}
    2->{aRot=(tm*2200f)%3600f;aTail=aRot*1.9f;M.translateM(T,0,e.x,e.y,e.z);M.rotateM(T,0,dg(e.ang)+HELI_YAW,0f,1f,0f);M.rotateM(T,0,if(e.dead)35f else 18f,0f,0f,1f);M.rotateM(T,0,if(e.dead)0f else 4f+e.kick*3f,1f,0f,0f)
     draw(heli,T,VP,tn,em)}
    else->{M.translateM(T,0,e.x,e.y,e.z);M.rotateM(T,0,dg(e.ang),0f,1f,0f);M.rotateM(T,0,if(e.dead)60f else sin(e.t*.8f)*8f,0f,0f,1f);draw(if(e.k==3)jet else fighter,T,VP,tn,em)}}}
  for(t in trs){val dx=t.b[0]-t.a[0];val dy=t.b[1]-t.a[1];val dz=t.b[2]-t.a[2];val ln=sqrt(dx*dx+dy*dy+dz*dz);if(ln<.01f)continue
   M.setIdentityM(T,0);M.translateM(T,0,(t.a[0]+t.b[0])/2f,(t.a[1]+t.b[1])/2f,(t.a[2]+t.b[2])/2f);M.rotateM(T,0,dg(atan2(dx,dz)),0f,1f,0f);M.rotateM(T,0,-dg(asin(dy/ln)),1f,0f,0f)
   M.scaleM(T,0,t.w,t.w,ln/2f);draw(cube,T,VP,BK,floatArrayOf(1f,.85f,.4f),0f)}
  for(f in fxs){val fr=min((f.t/f.dur*f.n).toInt(),f.n-1)+f.f0;uvx=(fr%8)/8f;uvy=(fr/8)/9f;uvw=1f/8f;uvh=1f/9f
   M.setIdentityM(T,0);M.translateM(T,0,f.x,f.y,f.z);M.rotateM(T,0,-dg(yaw),0f,1f,0f);M.scaleM(T,0,f.s,f.s*.83f,1f);draw(quad,T,VP,null,null,-1f)}
  uvx=0f;uvy=0f;uvw=1f;uvh=1f
  // اسلحه اول‌شخص با انیمیشن: نوسان راه رفتن، تاخیر چرخش، پس‌زنی، فلش دهانه، ریلود
  if(vi<0){GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT);M.perspectiveM(P,0,60f,asp,.02f,10f)
  val mv=min(1f,hypot(In.mx,In.mz));val rl=if(reloadT>0f)sin(3.1416f*(1f-reloadT/1.8f)) else 0f
  val gx=.2f*(1f-adsT)+swx+cos(bob)*.008f*mv*(1f-adsT);val gy=-.19f+.06f*adsT+swy-abs(sin(bob))*.012f*mv*(1f-adsT)-rl*.2f-sw*.25f
  M.setIdentityM(T,0);M.translateM(T,0,gx,gy,-.5f+.1f*adsT+recoil*.06f);M.rotateM(T,0,recoil*4f-rl*40f-sw*30f,1f,0f,0f);M.rotateM(T,0,gyw[wi],0f,1f,0f);if(!(wi==2&&adsT>.6f))draw(gl[wi],T,P,null,null,0f)
  if(flash>0f){M.setIdentityM(T,0);M.translateM(T,0,gx,gy+.02f,-.88f);M.rotateM(T,0,Random.nextFloat()*90f,0f,0f,1f);M.scaleM(T,0,.035f,.035f,.07f);draw(cube,T,P,BK,floatArrayOf(1f,.8f,.3f),0f)}}}
}

class Hud(c:Context,val g:G):View(c){
 fun bm(n:String):Bitmap=BitmapFactory.decodeStream(context.assets.open("ui/$n"))
 val bp=Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG);val startR=RectF()
 val menuBg=bm("menu.jpg");val logo=bm("logo.png");val joyBase=bm("joy_base.png");val joyKnob=bm("joy_knob.png");val hpBar=bm("hp_bar.png");val btnFire=bm("btn_fire.png");val barHi=bm("bar_hi.png");val icoReload=bm("ico_reload.png");val icoSwap=bm("ico_swap.png");val icoCross=bm("ico_crosshair.png");val icoMissile=bm("ico_missile.png");val icoRocket=bm("ico_rocket.png");val icoAfter=bm("ico_afterburner.png");val icoEnter=bm("ico_enter.png");val icoExit=bm("ico_exit.png");val scopeRet=bm("scope_ret.png");val icoRadar=bm("ico_radar.png")
 val p=Paint(Paint.ANTI_ALIAS_FLAG);val d=resources.displayMetrics.density
 var mid=-1;var lid=-1;var fid=-1;var rid=-1;var aid=-1;var bid=-1;var cid=-1;val sensM=RectF();val sensP=RectF();var ox=0f;var oy=0f;var lx=0f;var ly=0f;var kx=0f;var ky=0f
 fun fb()=floatArrayOf(width-110*d,height-110*d)
 fun rb()=floatArrayOf(width-110*d,height-235*d)
 fun sb()=floatArrayOf(width-235*d,height-110*d)
 fun ub()=floatArrayOf(width-235*d,height-235*d)
 fun bb()=floatArrayOf(width-360*d,height-110*d)
 fun cb()=floatArrayOf(width-360*d,height-235*d)
 override fun onTouchEvent(e:MotionEvent):Boolean{val a=e.actionMasked
  if(g.menu){if(a==MotionEvent.ACTION_DOWN){if(startR.contains(e.x,e.y))In.restart=true else if(sensM.contains(e.x,e.y))g.sens=(g.sens-.25f).coerceAtLeast(.5f) else if(sensP.contains(e.x,e.y))g.sens=(g.sens+.25f).coerceAtMost(2.5f)};return true}
  if(a==MotionEvent.ACTION_DOWN||a==MotionEvent.ACTION_POINTER_DOWN){val i=e.actionIndex;val id=e.getPointerId(i);val x=e.getX(i);val y=e.getY(i);val f=fb();val r=rb()
   if(g.over)In.restart=true
   else if(hypot(x-f[0],y-f[1])<75*d){fid=id;In.fire=true}
   else if(hypot(x-r[0],y-r[1])<45*d){rid=id;In.reload=true}
   else if((g.vkind<0||g.vkind>=2)&&hypot(x-sb()[0],y-sb()[1])<45*d){if(g.vkind<0)In.sw=true else{aid=id;In.a=true}}
   else if((g.vkind<0||g.vkind==2||g.vkind>=3)&&hypot(x-bb()[0],y-bb()[1])<45*d){if(g.vkind<0)In.zoom=true else{bid=id;In.b=true}}
   else if((g.vkind<0||g.vkind>=3)&&hypot(x-cb()[0],y-cb()[1])<45*d){if(g.vkind<0)In.jump=true else{cid=id;In.c=true}}
   else if(g.vkind>=0&&hypot(x-(width-80*d),y-80*d)<40*d)In.cam=true
   else if((g.canEnter||g.vkind>=0)&&hypot(x-ub()[0],y-ub()[1])<45*d)In.use=true
   else if(x<width*.45f&&mid<0){mid=id;ox=x;oy=y;kx=x;ky=y}
   else if(lid<0){lid=id;lx=x;ly=y}
  }else if(a==MotionEvent.ACTION_MOVE){for(i in 0 until e.pointerCount){val id=e.getPointerId(i);val x=e.getX(i);val y=e.getY(i)
    if(id==mid){In.mx=((x-ox)/(60*d)).coerceIn(-1f,1f);In.mz=((y-oy)/(60*d)).coerceIn(-1f,1f);kx=x;ky=y}
    else if(id==lid){In.ldx+=x-lx;In.ldy+=y-ly;lx=x;ly=y}}
  }else if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_POINTER_UP||a==MotionEvent.ACTION_CANCEL){val id=e.getPointerId(e.actionIndex)
   if(a==MotionEvent.ACTION_CANCEL){mid=-1;lid=-1;fid=-1;rid=-1;aid=-1;bid=-1;cid=-1;In.a=false;In.b=false;In.c=false;In.mx=0f;In.mz=0f;In.fire=false}
   else{if(id==mid){mid=-1;In.mx=0f;In.mz=0f};if(id==lid)lid=-1;if(id==fid){fid=-1;In.fire=false};if(id==rid)rid=-1;if(id==aid){aid=-1;In.a=false};if(id==bid){bid=-1;In.b=false};if(id==cid){cid=-1;In.c=false}}}
  return true}
 override fun onDraw(cv:Canvas){val cx=width/2f;val cy=height/2f
  if(g.menu){val t=System.nanoTime()/1e9f;val sc=max(width/menuBg.width.toFloat(),height/menuBg.height.toFloat())*(1.05f+.025f*sin(t*.5f));val bw=menuBg.width*sc;val bh=menuBg.height*sc
   cv.drawBitmap(menuBg,null,RectF((width-bw)/2f,(height-bh)/2f,(width+bw)/2f,(height+bh)/2f),bp)
   p.style=Paint.Style.FILL;p.color=0x44000000;cv.drawRect(0f,0f,width.toFloat(),height.toFloat(),p)
   val lw=min(width*.42f,height*.62f*logo.width/logo.height)*(1f+.015f*sin(t*2f));val lh=lw*logo.height/logo.width;cv.drawBitmap(logo,null,RectF(cx-lw/2f,14*d,cx+lw/2f,14*d+lh),bp)
   val bwd=width*.32f;val bht=bwd*barHi.height/barHi.width;val by=height-bht-30*d;startR.set(cx-bwd/2f,by,cx+bwd/2f,by+bht)
   bp.alpha=(215+40*sin(t*3f)).toInt();cv.drawBitmap(barHi,null,startR,bp);bp.alpha=255
   p.color=0xFFFFFFFF.toInt();p.textAlign=Paint.Align.CENTER;p.textSize=bht*.42f;p.isFakeBoldText=true;cv.drawText("شروع نبرد",cx,by+bht*.64f,p);p.isFakeBoldText=false
   val bs=46*d;sensM.set(24*d,height-bs-24*d,24*d+bs,height-24*d);sensP.set(24*d+bs+150*d,height-bs-24*d,24*d+2*bs+150*d,height-24*d)
   p.color=0x99000000.toInt();cv.drawRect(sensM,p);cv.drawRect(sensP,p);p.color=0xFFFFFFFF.toInt();p.textSize=26*d;cv.drawText("−",sensM.centerX(),sensM.centerY()+9*d,p);cv.drawText("+",sensP.centerX(),sensP.centerY()+9*d,p)
   p.textSize=18*d;cv.drawText("حساسیت ${"%.2f".format(g.sens)}",(sensM.right+sensP.left)/2f,sensM.centerY()+7*d,p)
   postInvalidateOnAnimation();return}
  p.style=Paint.Style.STROKE;p.strokeWidth=2*d;p.color=0xFFFFFFFF.toInt()
  cv.drawLine(cx-14*d,cy,cx-5*d,cy,p);cv.drawLine(cx+5*d,cy,cx+14*d,cy,p);cv.drawLine(cx,cy-14*d,cx,cy-5*d,p);cv.drawLine(cx,cy+5*d,cx,cy+14*d,p)
  if(g.hitM>0f){p.color=0xFFFF4040.toInt();cv.drawLine(cx-10*d,cy-10*d,cx+10*d,cy+10*d,p);cv.drawLine(cx+10*d,cy-10*d,cx-10*d,cy+10*d,p)}
  if(g.dmgF>0f){p.style=Paint.Style.FILL;p.color=((g.dmgF*300f).toInt().coerceIn(0,120) shl 24) or 0xFF0000;cv.drawRect(0f,0f,width.toFloat(),height.toFloat(),p)}
  p.style=Paint.Style.FILL;val hx=18*d;val hy=10*d;val hw=300*d;val hh=hw*hpBar.height/hpBar.width;cv.drawBitmap(hpBar,null,RectF(hx,hy,hx+hw,hy+hh),bp)
  p.color=0xFF0D0D0D.toInt();val hf=g.hp/100f;cv.drawRect(hx+hw*(.20f+.715f*hf),hy+hh*.27f,hx+hw*.915f,hy+hh*.8f,p)
  p.color=0xFFFFFFFF.toInt();p.textSize=20*d;p.textAlign=Paint.Align.CENTER;cv.drawText("موج ${g.wave}  |  امتیاز ${g.score}",cx,34*d,p)
  p.textAlign=Paint.Align.RIGHT;p.textSize=28*d;cv.drawText(if(g.vkind>=0)g.vname else if(g.reloadT>0f)"…" else "${g.ammo}/${g.mag}",width-24*d,height-200*d-70*d,p)
  val f=fb();val r=rb()
  cv.drawBitmap(btnFire,null,RectF(f[0]-62*d,f[1]-62*d,f[0]+62*d,f[1]+62*d),bp)
  val vk=g.vkind
  val ic2=when(vk){-1->icoReload;0->icoCross;2->icoRocket;else->icoMissile}
  p.color=0x99000000.toInt();cv.drawCircle(r[0],r[1],34*d,p);cv.drawBitmap(ic2,null,RectF(r[0]-24*d,r[1]-24*d,r[0]+24*d,r[1]+24*d),bp)
  if(vk>=0&&g.c2f<1f){p.color=0xCC000000.toInt();cv.drawArc(RectF(r[0]-34*d,r[1]-34*d,r[0]+34*d,r[1]+34*d),-90f,360f*(1f-g.c2f),true,p)}
  val sbb=sb()
  if(vk<0||vk>=2){val ic=when(vk){-1->icoSwap;2->icoExit;else->icoAfter};p.color=0x99000000.toInt();cv.drawCircle(sbb[0],sbb[1],34*d,p);if(vk!=2)cv.drawBitmap(ic,null,RectF(sbb[0]-26*d,sbb[1]-24*d,sbb[0]+26*d,sbb[1]+24*d),bp)else{p.color=0xFFFFFFFF.toInt();p.textAlign=Paint.Align.CENTER;p.textSize=15*d;cv.drawText("صعود",sbb[0],sbb[1]+5*d,p)}}
  val bb2=bb();val cc2=cb()
  if(vk<0||vk==2||vk>=3){p.color=0x99000000.toInt();cv.drawCircle(bb2[0],bb2[1],34*d,p);p.color=0xFFFFFFFF.toInt();p.textAlign=Paint.Align.CENTER;p.textSize=15*d;cv.drawText(when(vk){-1->"زوم";2->"فرود";else->"+"},bb2[0],bb2[1]+5*d,p)}
  if(vk<0||vk>=3){p.color=0x99000000.toInt();cv.drawCircle(cc2[0],cc2[1],34*d,p);p.color=0xFFFFFFFF.toInt();p.textAlign=Paint.Align.CENTER;p.textSize=15*d;cv.drawText(if(vk<0)"پرش" else "−",cc2[0],cc2[1]+5*d,p)}
  if(vk>=0){p.color=0x99000000.toInt();cv.drawCircle(width-80*d,80*d,32*d,p);cv.drawBitmap(icoRadar,null,RectF(width-102*d,58*d,width-58*d,102*d),bp)}
  if(g.canEnter||vk>=0){val ub2=ub();p.color=0x99000000.toInt();cv.drawCircle(ub2[0],ub2[1],38*d,p);val ic=if(vk<0)icoEnter else icoExit;cv.drawBitmap(ic,null,RectF(ub2[0]-30*d,ub2[1]-28*d,ub2[0]+30*d,ub2[1]+28*d),bp)}
  p.color=0xFFFFFFFF.toInt();p.textAlign=Paint.Align.CENTER
  if((g.scope&&vk==0)||(vk<0&&g.wi==2&&g.adsT>.55f)){val w2=height*scopeRet.width/scopeRet.height.toFloat();p.style=Paint.Style.FILL;p.color=0xFF000000.toInt();cv.drawRect(0f,0f,cx-w2/2f,height.toFloat(),p);cv.drawRect(cx+w2/2f,0f,width.toFloat(),height.toFloat(),p)
   cv.drawBitmap(scopeRet,null,RectF(cx-w2/2f,0f,cx+w2/2f,height.toFloat()),bp);p.color=0xFF39FF14.toInt();p.textAlign=Paint.Align.CENTER;p.textSize=18*d;if(vk==0)cv.drawText("${g.rng.toInt()} m",cx,height-22*d,p)}
  if(vk>=3){p.color=0xFF39FF14.toInt();p.style=Paint.Style.STROKE;p.strokeWidth=2*d;cv.save();cv.rotate(-dg(g.frl),cx,cy);val oy2=g.fpt*height*.55f
   cv.drawLine(cx-170*d,cy+oy2,cx-40*d,cy+oy2,p);cv.drawLine(cx+40*d,cy+oy2,cx+170*d,cy+oy2,p);cv.restore();cv.drawCircle(cx,cy,10*d,p)
   p.style=Paint.Style.FILL;p.textSize=20*d;p.textAlign=Paint.Align.LEFT;cv.drawText("${g.fsp.toInt()} km/h",24*d,cy,p);p.textAlign=Paint.Align.RIGHT;cv.drawText("${g.falt.toInt()} m",width-24*d,cy,p);p.textAlign=Paint.Align.CENTER;cv.drawText("${g.fhd.toInt()}°",cx,70*d,p);p.textAlign=Paint.Align.LEFT;cv.drawText("تراست ${(g.fth*100).toInt()}%",24*d,cy+30*d,p)}
  val jx=if(mid>=0)ox else 130*d;val jy=if(mid>=0)oy else height-130*d;var kdx=if(mid>=0)kx-jx else 0f;var kdy=if(mid>=0)ky-jy else 0f;val kl=hypot(kdx,kdy);if(kl>55*d){kdx*=55*d/kl;kdy*=55*d/kl}
  bp.alpha=if(mid>=0)255 else 110;cv.drawBitmap(joyBase,null,RectF(jx-75*d,jy-75*d,jx+75*d,jy+75*d),bp);cv.drawBitmap(joyKnob,null,RectF(jx+kdx-30*d,jy+kdy-30*d,jx+kdx+30*d,jy+kdy+30*d),bp);bp.alpha=255
  if(g.over){p.color=0xAA000000.toInt();cv.drawRect(0f,0f,width.toFloat(),height.toFloat(),p);p.color=0xFFFFFFFF.toInt();p.textAlign=Paint.Align.CENTER
   p.textSize=36*d;cv.drawText("پایان بازی — امتیاز ${g.score}",cx,cy-10*d,p);p.textSize=20*d;cv.drawText("برای شروع دوباره لمس کن",cx,cy+30*d,p)}
  postInvalidateOnAnimation()}
}
