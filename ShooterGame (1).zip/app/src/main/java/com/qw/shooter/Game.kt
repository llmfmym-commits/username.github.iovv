package com.qw.shooter
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.graphics.Canvas
import android.graphics.Paint
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix as M
import android.view.MotionEvent
import android.view.View
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*
import kotlin.random.Random

// جهت‌ها: اگر مدلی عقب‌رو یا کج دیده شد فقط همین چهار عدد را تغییر بده
const val GUN_YAW=90f
const val SOL_YAW=0f
const val TANK_YAW=0f
const val HELI_YAW=0f
fun dg(r:Float)=r*57.29578f

object In{@Volatile var mx=0f;@Volatile var mz=0f;@Volatile var fire=false;@Volatile var reload=false;@Volatile var ldx=0f;@Volatile var ldy=0f;@Volatile var restart=false;@Volatile var sw=false}
class Part(val vb:Int,val ib:Int,val n:Int,val tex:Int,val col:FloatArray)
class Mdl(val parts:List<Part>)
class En(val k:Int,var x:Float,var z:Float){var y=0f;var hp=1f;var t=0f;var dead=false;var dd=0f;var hit=0f;var cd=1.5f;var r=.45f;var y0=0f;var y1=1.8f;var v=0;var ang=0f;var kick=0f;var sp=2f;var a0=0f;var vy=0f;var walk=false;var sx=0f;var sz=0f}
class Pk(val x:Float,val z:Float)
class Fx(val x:Float,val y:Float,val z:Float,val s:Float,val f0:Int,val n:Int,val dur:Float){var t=0f}
class Ob(val x:Float,val z:Float,val yaw:Float,val k:Int,val r:Float)
class Tr(val a:FloatArray,val b:FloatArray,var l:Float)

class G(val c:Context):GLSurfaceView.Renderer{
 var prog=0;var white=0;var uMVP=0;var uM=0;var uC=0;var uE=0;var uCam=0;var uFog=0
 val tc=HashMap<String,Int>()
 lateinit var sky:Mdl;lateinit var quad:Mdl;val fxs=ArrayList<Fx>();@Volatile var menu=true;var uvx=0f;var uvy=0f;var uvw=1f;var uvh=1f;var uUV=0
 lateinit var gun:Mdl;lateinit var gl:List<Mdl>;lateinit var tower:Mdl;lateinit var trailer:Mdl;lateinit var ammoM:Mdl;lateinit var jet:Mdl;lateinit var fighter:Mdl;lateinit var sol:List<Mdl>;lateinit var tank:Mdl;lateinit var heli:Mdl;lateinit var bag:Mdl;lateinit var wire:Mdl;lateinit var cube:Mdl;lateinit var gnd:Mdl
 val en=ArrayList<En>();val obs=ArrayList<Ob>();val trs=ArrayList<Tr>()
 @Volatile var hp=100f;@Volatile var wi=0;val am=IntArray(3){30};val mg=intArrayOf(30,30,10);val rt=floatArrayOf(.11f,.08f,.55f);val dm=floatArrayOf(1f,.8f,4f);val gyw=floatArrayOf(90f,-90f,90f);val ammo:Int get()=am[wi];val mag:Int get()=mg[wi];var sw=0f;var jt=15f;val pks=ArrayList<Pk>();@Volatile var wave=0;@Volatile var score=0;@Volatile var over=false;@Volatile var dmgF=0f;@Volatile var hitM=0f;@Volatile var reloadT=0f
 var rld=false;var px=0f;var pz=0f;var yaw=0f;var pitch=0f;var cd=0f;var recoil=0f;var flash=0f;var bob=0f;var swx=0f;var swy=0f;var shake=0f;var tm=0f;var last=System.nanoTime();var w=1;var h=1;var waveT=0f
 val P=FloatArray(16);val V=FloatArray(16);val VP=FloatArray(16);val T=FloatArray(16);val MM=FloatArray(16)
 val Z3=floatArrayOf(0f,0f,0f);val DK=floatArrayOf(.3f,.3f,.3f,1f);val BK=floatArrayOf(0f,0f,0f,1f)

 fun sh(t:Int,s:String):Int{val i=GLES30.glCreateShader(t);GLES30.glShaderSource(i,s);GLES30.glCompileShader(i);return i}
 fun tex(n:String):Int=tc.getOrPut(n){val b=BitmapFactory.decodeStream(c.assets.open(if(n.contains('/'))n else "t/$n"));val a=IntArray(1);GLES30.glGenTextures(1,a,0)
  GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,a[0]);GLUtils.texImage2D(GLES30.GL_TEXTURE_2D,0,b,0);GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
  GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MIN_FILTER,GLES30.GL_LINEAR_MIPMAP_LINEAR);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MAG_FILTER,GLES30.GL_LINEAR);b.recycle();a[0]}
 fun mk(v:ByteBuffer,nv:Int,i:ByteBuffer,ni:Int,tx:Int,col:FloatArray):Part{val a=IntArray(2);GLES30.glGenBuffers(2,a,0)
  v.position(0);GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER,a[0]);GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER,nv*32,v,GLES30.GL_STATIC_DRAW)
  i.position(0);GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER,a[1]);GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER,ni*2,i,GLES30.GL_STATIC_DRAW);return Part(a[0],a[1],ni,tx,col)}
 fun load(f:String):Mdl{val b=ByteBuffer.wrap(c.assets.open("m/$f").readBytes()).order(ByteOrder.LITTLE_ENDIAN);val ps=ArrayList<Part>()
  repeat(b.int){val nv=b.int;val ni=b.int;val col=FloatArray(4){b.float};val ln=b.int;val nm=ByteArray(ln);b.get(nm)
   val v=ByteBuffer.allocateDirect(nv*32).order(ByteOrder.nativeOrder());val vb=ByteArray(nv*32);b.get(vb);v.put(vb)
   val i=ByteBuffer.allocateDirect(ni*2).order(ByteOrder.nativeOrder());val ib=ByteArray(ni*2);b.get(ib);i.put(ib)
   ps.add(mk(v,nv,i,ni,if(ln>0)tex(String(nm)) else white,col))}
  return Mdl(ps)}
 fun mesh(v:FloatArray,ix:ShortArray,tx:Int):Mdl{val vb=ByteBuffer.allocateDirect(v.size*4).order(ByteOrder.nativeOrder());vb.asFloatBuffer().put(v)
  val ib=ByteBuffer.allocateDirect(ix.size*2).order(ByteOrder.nativeOrder());ib.asShortBuffer().put(ix);return Mdl(listOf(mk(vb,v.size/8,ib,ix.size,tx,floatArrayOf(1f,1f,1f,1f))))}

 override fun onSurfaceCreated(g:GL10?,e:EGLConfig?){
  tc.clear()
  val vs="""#version 300 es
layout(location=0) in vec3 aP;layout(location=1) in vec3 aN;layout(location=2) in vec2 aT;uniform mat4 uMVP;uniform mat4 uM;uniform vec4 uUV;out vec2 vT;out vec3 vN;out vec3 vW;
void main(){vT=aT*uUV.zw+uUV.xy;vN=mat3(uM)*aN;vW=(uM*vec4(aP,1.)).xyz;gl_Position=uMVP*vec4(aP,1.);}"""
  val fs="""#version 300 es
precision mediump float;uniform sampler2D uS;uniform vec4 uC;uniform vec3 uE;uniform vec3 uCam;uniform float uFog;in vec2 vT;in vec3 vN;in vec3 vW;out vec4 o;
void main(){vec4 t=texture(uS,vT);vec3 n=normalize(vN);float l=uFog<-.5?1.:max(dot(n,normalize(vec3(.4,.8,.3))),0.)*.65+.5;vec3 c=t.rgb*uC.rgb*l+uE;float f=uFog>0.?clamp((length(vW-uCam)-40.)/110.,0.,1.):0.;o=vec4(mix(c,vec3(.66,.47,.30),f),uC.a*t.a);}"""
  prog=GLES30.glCreateProgram();GLES30.glAttachShader(prog,sh(GLES30.GL_VERTEX_SHADER,vs));GLES30.glAttachShader(prog,sh(GLES30.GL_FRAGMENT_SHADER,fs));GLES30.glLinkProgram(prog)
  uMVP=GLES30.glGetUniformLocation(prog,"uMVP");uM=GLES30.glGetUniformLocation(prog,"uM");uC=GLES30.glGetUniformLocation(prog,"uC");uE=GLES30.glGetUniformLocation(prog,"uE");uCam=GLES30.glGetUniformLocation(prog,"uCam");uFog=GLES30.glGetUniformLocation(prog,"uFog");uUV=GLES30.glGetUniformLocation(prog,"uUV")
  for(i in 0..2)GLES30.glEnableVertexAttribArray(i)
  val a=IntArray(1);GLES30.glGenTextures(1,a,0);white=a[0];GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,white)
  val wb=ByteBuffer.allocateDirect(4);wb.put(byteArrayOf(-1,-1,-1,-1));wb.position(0)
  GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D,0,GLES30.GL_RGBA,1,1,0,GLES30.GL_RGBA,GLES30.GL_UNSIGNED_BYTE,wb)
  GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MIN_FILTER,GLES30.GL_LINEAR);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MAG_FILTER,GLES30.GL_LINEAR)
  gun=load("gun.bin");sol=List(3){load("sol$it.bin")};tank=load("tank.bin");heli=load("heli.bin");bag=load("sandbag.bin");wire=load("wire.bin")
  gl=listOf(gun,load("gun2.bin"),load("gun4.bin"));tower=load("tower.bin");trailer=load("trailer.bin");ammoM=load("ammo.bin");jet=load("jet.bin");fighter=load("fighter.bin")
  val cv=ArrayList<Float>();val ci=ArrayList<Short>()
  for(ax in 0..2)for(s in intArrayOf(-1,1)){val b=(ax+1)%3;val d=(ax+2)%3;val base=cv.size/8
   for(q in 0..3){val p=FloatArray(3);p[ax]=s.toFloat();p[b]=if(q and 1==0)-1f else 1f;p[d]=if(q and 2==0)-1f else 1f
    cv.addAll(listOf(p[0],p[1],p[2],if(ax==0)s.toFloat() else 0f,if(ax==1)s.toFloat() else 0f,if(ax==2)s.toFloat() else 0f,0f,0f))}
   for(k in intArrayOf(0,1,2,1,3,2))ci.add((base+k).toShort())}
  cube=mesh(cv.toFloatArray(),ci.toShortArray(),white)
  gnd=mesh(floatArrayOf(-150f,0f,-150f,0f,1f,0f,-37f,-37f,150f,0f,-150f,0f,1f,0f,37f,-37f,-150f,0f,150f,0f,1f,0f,-37f,37f,150f,0f,150f,0f,1f,0f,37f,37f),shortArrayOf(0,1,2,1,3,2),tex("ground.jpg"))
  GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_S,GLES30.GL_REPEAT)
  val sv=ArrayList<Float>();val si=ArrayList<Short>()
  for(i in 0..16)for(j in 0..32){val th=3.14159f*i/16f;val ph=6.28318f*j/32f;sv.addAll(listOf(sin(th)*cos(ph),cos(th),sin(th)*sin(ph),0f,1f,0f,j/32f,i/16f))}
  for(i in 0 until 16)for(j in 0 until 32){val a=i*33+j;for(k in intArrayOf(a,a+33,a+1,a+1,a+33,a+34))si.add(k.toShort())}
  sky=mesh(sv.toFloatArray(),si.toShortArray(),tex("ui/sky.jpg"))
  quad=mesh(floatArrayOf(-.5f,-.5f,0f,0f,0f,1f,0f,1f,.5f,-.5f,0f,0f,0f,1f,1f,1f,-.5f,.5f,0f,0f,0f,1f,0f,0f,.5f,.5f,0f,0f,0f,1f,1f,0f),shortArrayOf(0,1,2,1,3,2),tex("ui/exp.png"));quad.parts[0].col[3]=.98f
  obs.clear();val rn=Random(7)
  repeat(18){val a2=rn.nextFloat()*6.283f;val r=9f+rn.nextFloat()*52f;val k=if(it%3==2)1 else 0;obs.add(Ob(sin(a2)*r,cos(a2)*r,rn.nextFloat()*360f,k,if(k==0)1.6f else 2.4f))}
  obs.add(Ob(-28f,-22f,0f,2,2.8f));obs.add(Ob(30f,18f,30f,3,5.5f));obs.add(Ob(-14f,36f,100f,3,5.5f))
  reset()}
 override fun onSurfaceChanged(g:GL10?,ww:Int,hh:Int){GLES30.glViewport(0,0,ww,hh);w=ww;h=hh}

 fun boom(x:Float,y:Float,z:Float,sc:Float,f0:Int,n:Int,dur:Float){fxs.add(Fx(x,y,z,sc,f0,n,dur))}
 fun reset(){fxs.clear();en.clear();trs.clear();hp=100f;for(i in 0..2)am[i]=mg[i];wi=0;sw=0f;jt=15f;pks.clear();wave=0;score=0;over=false;px=0f;pz=0f;yaw=0f;pitch=0f;rld=false;reloadT=0f;waveT=0f;nextWave()}
 fun nextWave(){wave++
  repeat(2){val a=Random.nextFloat()*6.283f;val r=8f+Random.nextFloat()*42f;pks.add(Pk(sin(a)*r,cos(a)*r))}
  fun pos():FloatArray{val a=Random.nextFloat()*6.283f;val r=38f+Random.nextFloat()*17f;return floatArrayOf(sin(a)*r,cos(a)*r)}
  repeat(3+wave*2){val p=pos();en.add(En(0,p[0],p[1]).apply{hp=3f+wave*.3f;sp=min(1.8f+wave*.15f,4.2f);a0=9f+Random.nextFloat()*7f;v=Random.nextInt(3)})}
  if(wave%3==0){val p=pos();en.add(En(1,p[0],p[1]).apply{hp=30f;r=2.6f;y1=3f;cd=3f})}
  if(wave>=4&&wave%2==0){en.add(En(2,0f,42f).apply{hp=14f;r=3.2f;y=17f;cd=3f;a0=Random.nextFloat()*6f})}}
 fun spawnJet(){val a=Random.nextFloat()*6.283f;val e=En(3+Random.nextInt(2),sin(a)*125f,cos(a)*125f);val dx=(Random.nextFloat()-.5f)*60f-e.x;val dz=(Random.nextFloat()-.5f)*60f-e.z;val d=hypot(dx,dz)
  e.sx=dx/d*48f;e.sz=dz/d*48f;e.y=38f+Random.nextFloat()*10f;e.hp=6f;e.r=5f;en.add(e)}
 fun hurt(d:Float){hp-=d;dmgF=.4f;shake=.06f;if(hp<=0f){hp=0f;over=true}}
 fun push(e:En){for(o in obs){val dx=e.x-o.x;val dz=e.z-o.z;val d=hypot(dx,dz);val m=o.r+e.r+.2f;if(d<m&&d>1e-3f){e.x=o.x+dx/d*m;e.z=o.z+dz/d*m}}}
 fun shoot(){recoil=1f;flash=.05f;shake+=.015f
  val cp=cos(pitch);val fx=sin(yaw)*cp;val fy=sin(pitch);val fz=-cos(yaw)*cp;var bt=60f;var be:En?=null
  for(e in en){if(e.dead)continue;val ox=px-e.x;val oz=pz-e.z;val a=fx*fx+fz*fz;if(a<1e-6f)continue
   val b=2f*(ox*fx+oz*fz);val cc=ox*ox+oz*oz-e.r*e.r;val ds=b*b-4f*a*cc;if(ds<0f)continue
   val t=(-b-sqrt(ds))/(2f*a);if(t<0f||t>=bt)continue;val yy=1.6f+fy*t;if(yy<e.y0||yy>e.y1)continue;bt=t;be=e}
  trs.add(Tr(floatArrayOf(px+cos(yaw)*.2f+fx*.6f,1.45f+fy*.6f,pz+sin(yaw)*.2f+fz*.6f),floatArrayOf(px+fx*bt,1.6f+fy*bt,pz+fz*bt),.05f))
  be?.let{boom(px+fx*bt,1.6f+fy*bt,pz+fz*bt,.8f,64,8,.25f);val hs=it.k==0&&1.6f+fy*bt>it.y0+1.45f;it.hp-=dm[wi]*(if(hs)2f else 1f);it.hit=.15f;hitM=.2f
   if(it.hp<=0f){it.dead=true;it.dd=0f;when(it.k){0->boom(it.x,.9f,it.z,2.4f,48,8,.5f);1->boom(it.x,2f,it.z,11f,0,32,1.8f);else->boom(it.x,it.y,it.z,10f,0,32,1.6f)};score+=when(it.k){0->10;1->100;2->150;else->200}}}}

 fun upd(dt:Float){tm+=dt
  if(menu){In.ldx=0f;In.ldy=0f;if(In.restart){In.restart=false;menu=false;reset()};return}
  if(In.restart){In.restart=false;if(over)reset()}
  dmgF=max(0f,dmgF-dt);hitM=max(0f,hitM-dt);shake=max(0f,shake-dt*.3f)
  for(i in trs.indices.reversed()){trs[i].l-=dt;if(trs[i].l<=0f)trs.removeAt(i)}
  for(i in fxs.indices.reversed()){fxs[i].t+=dt;if(fxs[i].t>fxs[i].dur)fxs.removeAt(i)}
  val lx=In.ldx;val ly=In.ldy;In.ldx=0f;In.ldy=0f
  if(over)return
  yaw+=lx*.0045f;pitch=(pitch-ly*.004f).coerceIn(-1.2f,1.2f)
  val k=min(dt*10f,1f);swx+=((-lx*.0009f).coerceIn(-.04f,.04f)-swx)*k;swy+=((ly*.0007f).coerceIn(-.03f,.03f)-swy)*k
  val fx=sin(yaw);val fz=-cos(yaw);val rx=cos(yaw);val rz=sin(yaw)
  px+=(rx*In.mx-fx*In.mz)*5f*dt;pz+=(rz*In.mx-fz*In.mz)*5f*dt
  for(o in obs){val dx=px-o.x;val dz=pz-o.z;val d=hypot(dx,dz);val m=o.r+.4f;if(d<m&&d>1e-3f){px=o.x+dx/d*m;pz=o.z+dz/d*m}}
  val ar=hypot(px,pz);if(ar>70f){px*=70f/ar;pz*=70f/ar}
  bob+=dt*min(1f,hypot(In.mx,In.mz))*9f
  sw=max(0f,sw-dt*4f);if(In.sw){In.sw=false;wi=(wi+1)%3;rld=false;reloadT=0f;sw=1f}
  jt-=dt;if(jt<=0f&&wave>=2){jt=28f;spawnJet()}
  val pr=ArrayList<Pk>();for(q in pks)if(hypot(px-q.x,pz-q.z)<1.8f){hp=min(100f,hp+25f);for(i in 0..2)am[i]=mg[i];rld=false;pr.add(q)};pks.removeAll(pr)
  cd-=dt;reloadT=max(0f,reloadT-dt);recoil=max(0f,recoil-dt*9f);flash=max(0f,flash-dt)
  if(rld&&reloadT<=0f){am[wi]=mg[wi];rld=false}
  if(In.reload&&am[wi]<mg[wi]&&!rld){reloadT=1.8f;rld=true};In.reload=false
  if(In.fire&&cd<=0f&&!rld){if(am[wi]>0){shoot();cd=rt[wi];am[wi]--}else{reloadT=1.8f;rld=true}}
  val rm=ArrayList<En>()
  for(e in en){e.t+=dt;e.hit-=dt;e.kick=max(0f,e.kick-dt*4f)
   if(e.dead){e.dd+=dt;if(e.k>=2&&e.y>0f){e.vy+=dt*9f;e.y=max(0f,e.y-e.vy*dt);e.ang+=dt*6f;if(e.y<=0f)boom(e.x,2f,e.z,12f,0,32,1.8f)};if(e.dd>if(e.k==0)3f else 6f)rm.add(e);continue}
   val dx=px-e.x;val dz=pz-e.z;val d=max(hypot(dx,dz),.01f)
   when(e.k){
    0->{e.ang=atan2(dx,dz);e.walk=d>e.a0
     if(e.walk){e.x+=dx/d*e.sp*dt;e.z+=dz/d*e.sp*dt;push(e)}
     else{e.cd-=dt;if(e.cd<=0f){e.cd=1.1f+Random.nextFloat()*.8f;e.kick=1f;trs.add(Tr(floatArrayOf(e.x,1.3f,e.z),floatArrayOf(px,1.4f,pz),.07f));if(Random.nextFloat()<.4f)hurt(5f)}}}
    1->{e.ang=atan2(dx,dz);if(d>28f){e.x+=dx/d*1.6f*dt;e.z+=dz/d*1.6f*dt;push(e)}
     e.cd-=dt;if(e.cd<=0f){e.cd=3.5f;e.kick=1f;trs.add(Tr(floatArrayOf(e.x,2.6f,e.z),floatArrayOf(px,1.2f,pz),.2f));if(Random.nextFloat()<.7f)hurt(18f)}}
    2->{e.a0+=dt*.3f;val nx=sin(e.a0)*42f;val nz=cos(e.a0)*42f;val vx=nx-e.x;val vz=nz-e.z;if(abs(vx)+abs(vz)>1e-4f)e.ang=atan2(vx,vz)
     e.x=nx;e.z=nz;e.y=17f+sin(e.t*1.3f)*1.5f;e.y0=e.y-1.5f;e.y1=e.y+2.5f
     e.cd-=dt;if(e.cd<=0f){e.cd=4f;e.kick=1f;trs.add(Tr(floatArrayOf(e.x,e.y,e.z),floatArrayOf(px,1.3f,pz),.12f));if(Random.nextFloat()<.6f)hurt(10f)}}
    else->{e.x+=e.sx*dt;e.z+=e.sz*dt;e.ang=atan2(e.sx,e.sz);e.y0=e.y-2f;e.y1=e.y+2f;if(e.t>3f&&hypot(e.x,e.z)>140f)rm.add(e)}}}
  en.removeAll(rm)
  if(en.none{!it.dead&&it.k<3}){waveT+=dt;if(waveT>2.5f){waveT=0f;nextWave()}}}

 fun draw(m:Mdl,mm:FloatArray,vp:FloatArray,tint:FloatArray?=null,em:FloatArray?=null,fog:Float=1f){
  M.multiplyMM(MM,0,vp,0,mm,0);GLES30.glUniformMatrix4fv(uMVP,1,false,MM,0);GLES30.glUniformMatrix4fv(uM,1,false,mm,0)
  val e=em?:Z3;GLES30.glUniform3f(uE,e[0],e[1],e[2]);GLES30.glUniform1f(uFog,fog);GLES30.glUniform4f(uUV,uvx,uvy,uvw,uvh)
  val t=tint?:floatArrayOf(1f,1f,1f,1f)
  for(pass in 0..1){if(pass==1){GLES30.glEnable(GLES30.GL_BLEND);GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA,GLES30.GL_ONE_MINUS_SRC_ALPHA);GLES30.glDepthMask(false)}
   for(p in m.parts){if((p.col[3]<.99f)!=(pass==1))continue
    GLES30.glUniform4f(uC,p.col[0]*t[0],p.col[1]*t[1],p.col[2]*t[2],p.col[3]*t[3])
    GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,p.tex);GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER,p.vb);GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER,p.ib)
    GLES30.glVertexAttribPointer(0,3,GLES30.GL_FLOAT,false,32,0);GLES30.glVertexAttribPointer(1,3,GLES30.GL_FLOAT,false,32,12);GLES30.glVertexAttribPointer(2,2,GLES30.GL_FLOAT,false,32,24)
    GLES30.glDrawElements(GLES30.GL_TRIANGLES,p.n,GLES30.GL_UNSIGNED_SHORT,0)}}
  GLES30.glDisable(GLES30.GL_BLEND);GLES30.glDepthMask(true)}

 override fun onDrawFrame(g:GL10?){
  val now=System.nanoTime();val dt=min((now-last)/1e9f,.05f);last=now;upd(dt)
  if(menu){GLES30.glClearColor(0f,0f,0f,1f);GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);return}
  GLES30.glClearColor(.66f,.47f,.30f,1f);GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT);GLES30.glEnable(GLES30.GL_DEPTH_TEST);GLES30.glUseProgram(prog)
  val asp=w.toFloat()/h;val cp=cos(pitch);val sx=(Random.nextFloat()-.5f)*shake;val sy=(Random.nextFloat()-.5f)*shake
  val ey=1.6f+sy+if(over)-.9f else 0f
  M.setLookAtM(V,0,px+sx,ey,pz,px+sin(yaw)*cp,ey+sin(pitch),pz-cos(yaw)*cp,0f,1f,0f);M.perspectiveM(P,0,70f,asp,.1f,220f);M.multiplyMM(VP,0,P,0,V,0)
  GLES30.glUniform3f(uCam,px,1.6f,pz)
  GLES30.glDepthMask(false);M.setIdentityM(T,0);M.translateM(T,0,px,1.6f,pz);M.scaleM(T,0,190f,190f,190f);draw(sky,T,VP,null,null,-1f);GLES30.glDepthMask(true)
  M.setIdentityM(T,0);draw(gnd,T,VP)
  for(o in obs){M.setIdentityM(T,0);M.translateM(T,0,o.x,0f,o.z);M.rotateM(T,0,o.yaw,0f,1f,0f)
   when(o.k){1->draw(wire,T,VP);2->draw(tower,T,VP);3->draw(trailer,T,VP);else->for(i in -1..1){val t2=T.copyOf();M.translateM(t2,0,i*.95f,0f,0f);draw(bag,t2,VP)}}}
  for(q in pks){M.setIdentityM(T,0);M.translateM(T,0,q.x,.35f+sin(tm*3f)*.1f,q.z);M.rotateM(T,0,tm*90f,0f,1f,0f);draw(ammoM,T,VP,null,floatArrayOf(.15f,.12f,0f))}
  for(e in en){M.setIdentityM(T,0);val em=floatArrayOf(max(e.hit,0f)*4f,0f,0f);val tn=if(e.dead)DK else null
   when(e.k){
    0->{val wk=if(e.walk&&!e.dead)abs(sin(e.t*9f))*.07f else 0f
     M.translateM(T,0,e.x,wk,e.z);M.rotateM(T,0,dg(e.ang)+SOL_YAW,0f,1f,0f)
     if(e.dead)M.rotateM(T,0,-min(e.dd/.5f,1f)*88f,1f,0f,0f)
     else{M.rotateM(T,0,if(e.walk)sin(e.t*9f)*4f else 0f,0f,0f,1f);M.rotateM(T,0,(if(e.walk)7f else 0f)-e.kick*9f,1f,0f,0f)}
     draw(sol[e.v],T,VP,tn,em)}
    1->{M.translateM(T,0,e.x,if(e.dead)-min(e.dd*.15f,1.2f) else 0f,e.z);M.rotateM(T,0,dg(e.ang)+TANK_YAW,0f,1f,0f);M.translateM(T,0,0f,0f,-e.kick*.35f)
     if(!e.dead){M.rotateM(T,0,sin(e.t*1.7f)*.5f,0f,0f,1f);M.rotateM(T,0,sin(e.t*2.3f)*.25f,0f,0f,1f)}
     draw(tank,T,VP,tn,em)}
    2->{M.translateM(T,0,e.x,e.y,e.z);M.rotateM(T,0,dg(e.ang)+HELI_YAW,0f,1f,0f);M.rotateM(T,0,if(e.dead)35f else 18f,0f,0f,1f);M.rotateM(T,0,if(e.dead)0f else 4f+e.kick*3f,1f,0f,0f)
     draw(heli,T,VP,tn,em)}
    else->{M.translateM(T,0,e.x,e.y,e.z);M.rotateM(T,0,dg(e.ang),0f,1f,0f);M.rotateM(T,0,if(e.dead)60f else sin(e.t*.8f)*8f,0f,0f,1f);draw(if(e.k==3)jet else fighter,T,VP,tn,em)}}}
  for(t in trs){val dx=t.b[0]-t.a[0];val dy=t.b[1]-t.a[1];val dz=t.b[2]-t.a[2];val ln=sqrt(dx*dx+dy*dy+dz*dz);if(ln<.01f)continue
   M.setIdentityM(T,0);M.translateM(T,0,(t.a[0]+t.b[0])/2f,(t.a[1]+t.b[1])/2f,(t.a[2]+t.b[2])/2f);M.rotateM(T,0,dg(atan2(dx,dz)),0f,1f,0f);M.rotateM(T,0,-dg(asin(dy/ln)),1f,0f,0f)
   M.scaleM(T,0,.012f,.012f,ln/2f);draw(cube,T,VP,BK,floatArrayOf(1f,.85f,.4f),0f)}
  for(f in fxs){val fr=min((f.t/f.dur*f.n).toInt(),f.n-1)+f.f0;uvx=(fr%8)/8f;uvy=(fr/8)/9f;uvw=1f/8f;uvh=1f/9f
   M.setIdentityM(T,0);M.translateM(T,0,f.x,f.y,f.z);M.rotateM(T,0,-dg(yaw),0f,1f,0f);M.scaleM(T,0,f.s,f.s*.83f,1f);draw(quad,T,VP,null,null,-1f)}
  uvx=0f;uvy=0f;uvw=1f;uvh=1f
  // اسلحه اول‌شخص با انیمیشن: نوسان راه رفتن، تاخیر چرخش، پس‌زنی، فلش دهانه، ریلود
  GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT);M.perspectiveM(P,0,60f,asp,.02f,10f)
  val mv=min(1f,hypot(In.mx,In.mz));val rl=if(reloadT>0f)sin(3.1416f*(1f-reloadT/1.8f)) else 0f
  val gx=.2f+swx+cos(bob)*.008f*mv;val gy=-.19f+swy-abs(sin(bob))*.012f*mv-rl*.2f-sw*.25f
  M.setIdentityM(T,0);M.translateM(T,0,gx,gy,-.5f+recoil*.06f);M.rotateM(T,0,recoil*4f-rl*40f-sw*30f,1f,0f,0f);M.rotateM(T,0,gyw[wi],0f,1f,0f);draw(gl[wi],T,P,null,null,0f)
  if(flash>0f){M.setIdentityM(T,0);M.translateM(T,0,gx,gy+.02f,-.88f);M.rotateM(T,0,Random.nextFloat()*90f,0f,0f,1f);M.scaleM(T,0,.035f,.035f,.07f);draw(cube,T,P,BK,floatArrayOf(1f,.8f,.3f),0f)}}
}

class Hud(c:Context,val g:G):View(c){
 fun bm(n:String):Bitmap=BitmapFactory.decodeStream(context.assets.open("ui/$n"))
 val bp=Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG);val startR=RectF()
 val menuBg=bm("menu.jpg");val logo=bm("logo.png");val joyBase=bm("joy_base.png");val joyKnob=bm("joy_knob.png");val hpBar=bm("hp_bar.png");val btnFire=bm("btn_fire.png");val barHi=bm("bar_hi.png");val icoReload=bm("ico_reload.png");val icoSwap=bm("ico_swap.png")
 val p=Paint(Paint.ANTI_ALIAS_FLAG);val d=resources.displayMetrics.density
 var mid=-1;var lid=-1;var fid=-1;var rid=-1;var ox=0f;var oy=0f;var lx=0f;var ly=0f;var kx=0f;var ky=0f
 fun fb()=floatArrayOf(width-110*d,height-110*d)
 fun rb()=floatArrayOf(width-110*d,height-235*d)
 fun sb()=floatArrayOf(width-235*d,height-110*d)
 override fun onTouchEvent(e:MotionEvent):Boolean{val a=e.actionMasked
  if(g.menu){if(a==MotionEvent.ACTION_DOWN&&startR.contains(e.x,e.y))In.restart=true;return true}
  if(a==MotionEvent.ACTION_DOWN||a==MotionEvent.ACTION_POINTER_DOWN){val i=e.actionIndex;val id=e.getPointerId(i);val x=e.getX(i);val y=e.getY(i);val f=fb();val r=rb()
   if(g.over)In.restart=true
   else if(hypot(x-f[0],y-f[1])<75*d){fid=id;In.fire=true}
   else if(hypot(x-r[0],y-r[1])<45*d){rid=id;In.reload=true}
   else if(hypot(x-sb()[0],y-sb()[1])<45*d)In.sw=true
   else if(x<width*.45f&&mid<0){mid=id;ox=x;oy=y;kx=x;ky=y}
   else if(lid<0){lid=id;lx=x;ly=y}
  }else if(a==MotionEvent.ACTION_MOVE){for(i in 0 until e.pointerCount){val id=e.getPointerId(i);val x=e.getX(i);val y=e.getY(i)
    if(id==mid){In.mx=((x-ox)/(60*d)).coerceIn(-1f,1f);In.mz=((y-oy)/(60*d)).coerceIn(-1f,1f);kx=x;ky=y}
    else if(id==lid){In.ldx+=x-lx;In.ldy+=y-ly;lx=x;ly=y}}
  }else if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_POINTER_UP||a==MotionEvent.ACTION_CANCEL){val id=e.getPointerId(e.actionIndex)
   if(a==MotionEvent.ACTION_CANCEL){mid=-1;lid=-1;fid=-1;rid=-1;In.mx=0f;In.mz=0f;In.fire=false}
   else{if(id==mid){mid=-1;In.mx=0f;In.mz=0f};if(id==lid)lid=-1;if(id==fid){fid=-1;In.fire=false};if(id==rid)rid=-1}}
  return true}
 override fun onDraw(cv:Canvas){val cx=width/2f;val cy=height/2f
  if(g.menu){val t=System.nanoTime()/1e9f;val sc=max(width/menuBg.width.toFloat(),height/menuBg.height.toFloat())*(1.05f+.025f*sin(t*.5f));val bw=menuBg.width*sc;val bh=menuBg.height*sc
   cv.drawBitmap(menuBg,null,RectF((width-bw)/2f,(height-bh)/2f,(width+bw)/2f,(height+bh)/2f),bp)
   p.style=Paint.Style.FILL;p.color=0x44000000;cv.drawRect(0f,0f,width.toFloat(),height.toFloat(),p)
   val lw=min(width*.42f,height*.62f*logo.width/logo.height)*(1f+.015f*sin(t*2f));val lh=lw*logo.height/logo.width;cv.drawBitmap(logo,null,RectF(cx-lw/2f,14*d,cx+lw/2f,14*d+lh),bp)
   val bwd=width*.32f;val bht=bwd*barHi.height/barHi.width;val by=height-bht-30*d;startR.set(cx-bwd/2f,by,cx+bwd/2f,by+bht)
   bp.alpha=(215+40*sin(t*3f)).toInt();cv.drawBitmap(barHi,null,startR,bp);bp.alpha=255
   p.color=0xFFFFFFFF.toInt();p.textAlign=Paint.Align.CENTER;p.textSize=bht*.42f;p.isFakeBoldText=true;cv.drawText("شروع نبرد",cx,by+bht*.64f,p);p.isFakeBoldText=false
   postInvalidateOnAnimation();return}
  p.style=Paint.Style.STROKE;p.strokeWidth=2*d;p.color=0xFFFFFFFF.toInt()
  cv.drawLine(cx-14*d,cy,cx-5*d,cy,p);cv.drawLine(cx+5*d,cy,cx+14*d,cy,p);cv.drawLine(cx,cy-14*d,cx,cy-5*d,p);cv.drawLine(cx,cy+5*d,cx,cy+14*d,p)
  if(g.hitM>0f){p.color=0xFFFF4040.toInt();cv.drawLine(cx-10*d,cy-10*d,cx+10*d,cy+10*d,p);cv.drawLine(cx+10*d,cy-10*d,cx-10*d,cy+10*d,p)}
  if(g.dmgF>0f){p.style=Paint.Style.FILL;p.color=((g.dmgF*300f).toInt().coerceIn(0,120) shl 24) or 0xFF0000;cv.drawRect(0f,0f,width.toFloat(),height.toFloat(),p)}
  p.style=Paint.Style.FILL;val hx=18*d;val hy=10*d;val hw=300*d;val hh=hw*hpBar.height/hpBar.width;cv.drawBitmap(hpBar,null,RectF(hx,hy,hx+hw,hy+hh),bp)
  p.color=0xFF0D0D0D.toInt();val hf=g.hp/100f;cv.drawRect(hx+hw*(.20f+.715f*hf),hy+hh*.27f,hx+hw*.915f,hy+hh*.8f,p)
  p.color=0xFFFFFFFF.toInt();p.textSize=20*d;p.textAlign=Paint.Align.CENTER;cv.drawText("موج ${g.wave}  |  امتیاز ${g.score}",cx,34*d,p)
  p.textAlign=Paint.Align.RIGHT;p.textSize=28*d;cv.drawText(if(g.reloadT>0f)"…" else "${g.ammo}/${g.mag}",width-24*d,height-200*d-70*d,p)
  val f=fb();val r=rb()
  cv.drawBitmap(btnFire,null,RectF(f[0]-62*d,f[1]-62*d,f[0]+62*d,f[1]+62*d),bp)
  p.color=0x99000000.toInt();cv.drawCircle(r[0],r[1],34*d,p);cv.drawBitmap(icoReload,null,RectF(r[0]-24*d,r[1]-24*d,r[0]+24*d,r[1]+24*d),bp)
  val sbb=sb();cv.drawCircle(sbb[0],sbb[1],34*d,p);cv.drawBitmap(icoSwap,null,RectF(sbb[0]-26*d,sbb[1]-24*d,sbb[0]+26*d,sbb[1]+24*d),bp);p.color=0xFFFFFFFF.toInt();p.textAlign=Paint.Align.CENTER
  val jx=if(mid>=0)ox else 130*d;val jy=if(mid>=0)oy else height-130*d;var kdx=if(mid>=0)kx-jx else 0f;var kdy=if(mid>=0)ky-jy else 0f;val kl=hypot(kdx,kdy);if(kl>55*d){kdx*=55*d/kl;kdy*=55*d/kl}
  bp.alpha=if(mid>=0)255 else 110;cv.drawBitmap(joyBase,null,RectF(jx-75*d,jy-75*d,jx+75*d,jy+75*d),bp);cv.drawBitmap(joyKnob,null,RectF(jx+kdx-30*d,jy+kdy-30*d,jx+kdx+30*d,jy+kdy+30*d),bp);bp.alpha=255
  if(g.over){p.color=0xAA000000.toInt();cv.drawRect(0f,0f,width.toFloat(),height.toFloat(),p);p.color=0xFFFFFFFF.toInt();p.textAlign=Paint.Align.CENTER
   p.textSize=36*d;cv.drawText("پایان بازی — امتیاز ${g.score}",cx,cy-10*d,p);p.textSize=20*d;cv.drawText("برای شروع دوباره لمس کن",cx,cy+30*d,p)}
  postInvalidateOnAnimation()}
}
