import json,struct,io,sys,numpy as np
from PIL import Image
U='/mnt/user-data/uploads/';OUT='app/src/main/assets/'
CT={5120:np.int8,5121:np.uint8,5122:np.int16,5123:np.uint16,5125:np.uint32,5126:np.float32}
NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
class G:
    def __init__(s,f):
        d=open(U+f,'rb').read();L=struct.unpack('<I',d[12:16])[0]
        s.j=json.loads(d[20:20+L]);s.b=d[20+L+8:];s.tc={}
    def acc(s,i):
        a=s.j['accessors'][i];bv=s.j['bufferViews'][a['bufferView']];dt=np.dtype(CT[a['componentType']]);n=NC[a['type']]
        o=bv.get('byteOffset',0)+a.get('byteOffset',0);st=bv.get('byteStride',n*dt.itemsize)
        raw=np.frombuffer(s.b,np.uint8,count=st*(a['count']-1)+n*dt.itemsize,offset=o)
        arr=np.lib.stride_tricks.as_strided(raw,(a['count'],n*dt.itemsize),(st,1)).copy().view(dt).reshape(a['count'],n)
        if a.get('normalized'):arr=arr/float(np.iinfo(dt).max)
        return arr
    def tex(s,mi,mx,name):
        m=s.j['materials'][mi];pm=m.get('pbrMetallicRoughness',{});col=pm.get('baseColorFactor',[1,1,1,1]);t=pm.get('baseColorTexture')
        if t is None:return col,-1
        k=(t['index'],mx)
        if k not in s.tc:
            im=s.j['images'][s.j['textures'][t['index']]['source']];bv=s.j['bufferViews'][im['bufferView']]
            img=Image.open(io.BytesIO(s.b[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']])).convert('RGB')
            img.thumbnail((mx,mx));fn='%s_%d.jpg'%(name,len(s.tc));img.save(OUT+'t/'+fn,quality=80);s.tc[k]=fn
        return col,s.tc[k]
def _tex(s,mi,mx,name):
    col,tx=G.tex0(s,mi,mx,name);m=s.j['materials'][mi];nm=m.get('name','').lower();ex=m.get('extensions',{})
    if m.get('alphaMode')=='BLEND' or 'glass' in nm or 'KHR_materials_transmission' in ex:col=list(col);col[3]=min(col[3],.35)
    return col,tx
G.tex0=G.tex;G.tex=_tex
def local(n):
    if 'matrix' in n:return np.array(n['matrix']).reshape(4,4).T
    T=np.eye(4);T[:3,3]=n.get('translation',[0,0,0]);x,y,z,w=n.get('rotation',[0,0,0,1])
    R=np.eye(4);R[:3,:3]=[[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]]
    S=np.diag(list(n.get('scale',[1,1,1]))+[1]);return T@R@S
def worlds(j):
    N=j['nodes'];W=[None]*len(N);par={}
    for i,n in enumerate(N):
        for c in n.get('children',[]):par[c]=i
    def w(i):
        if W[i] is None:W[i]=(w(par[i]) if i in par else np.eye(4))@local(N[i])
        return W[i]
    for i in range(len(N)):w(i)
    return W,par
def collect(f,root=None,skip=(),name='m',mx=512):
    g=G(f);j=g.j;W,par=worlds(j);parts=[]
    def under(i):
        while i is not None:
            if i==root:return True
            i=par.get(i)
        return False
    for i,n in enumerate(j['nodes']):
        if 'mesh' not in n or (root is not None and not under(i)) or any(k in n.get('name','').lower() for k in skip):continue
        for p in j['meshes'][n['mesh']]['primitives']:
            if p.get('mode',4)!=4:continue
            a=p['attributes'];P=g.acc(a['POSITION']).astype(float);Nn=g.acc(a['NORMAL']).astype(float) if 'NORMAL' in a else np.tile([0,1,0.],(len(P),1))
            Uv=g.acc(a['TEXCOORD_0']).astype(float) if 'TEXCOORD_0' in a else np.zeros((len(P),2))
            I=g.acc(p['indices']).reshape(-1).astype(np.int64) if 'indices' in p else np.arange(len(P))
            if 'skin' in n and 'JOINTS_0' in a:
                sk=j['skins'][n['skin']];ibm=g.acc(sk['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1)
                jm=np.array([W[jn]@ibm[k] for k,jn in enumerate(sk['joints'])]);J=g.acc(a['JOINTS_0']).astype(int);Wt=g.acc(a['WEIGHTS_0']).astype(float)
                M=np.einsum('nk,nkab->nab',Wt,jm[J]);ph=np.c_[P,np.ones(len(P))]
                P=np.einsum('nab,nb->na',M,ph)[:,:3];Nn=np.einsum('nab,nb->na',M[:,:3,:3],Nn)
            else:
                P=(np.c_[P,np.ones(len(P))]@W[i].T)[:,:3];Nn=Nn@np.linalg.inv(W[i][:3,:3])
            col,tx=g.tex(p['material'],mx,name) if 'material' in p else ([1,1,1,1],-1)
            if 'glass' in n.get('name','').lower():col=list(col);col[3]=min(col[3],.35)
            parts.append(dict(P=P,N=Nn,U=Uv,I=I,col=col,tx=tx,bb=(P.min(0)+P.max(0))/2))
    return parts
def decim(P,N,Uv,I,target):
    T=I.reshape(-1,3)
    if len(T)<=target:return P,N,Uv,I
    ext=(P.max(0)-P.min(0)).max();lo,hi=ext*1e-4,ext/2;best=None;uq=np.floor(Uv*48).astype(np.int64)
    for _ in range(16):
        c=(lo*hi)**.5;q=np.floor((P-P.min(0))/c).astype(np.int64)
        u,fi,inv=np.unique(np.c_[q,uq],axis=0,return_index=True,return_inverse=True);inv=inv.reshape(-1);k=len(u)
        cnt=np.bincount(inv,minlength=k)[:,None];nP=np.zeros((k,3));nN=np.zeros((k,3));np.add.at(nP,inv,P);np.add.at(nN,inv,N)
        t=inv[T];ok=(t[:,0]!=t[:,1])&(t[:,1]!=t[:,2])&(t[:,0]!=t[:,2]);t=t[ok]
        if len(t)>target:lo=c
        else:hi=c;best=(nP/cnt,nN/(np.linalg.norm(nN,axis=1,keepdims=True)+1e-9),Uv[fi],t.reshape(-1))
    if best is None:best=(nP/cnt,nN,Uv[fi],t.reshape(-1))
    return best
def write(fn,parts,target,tf):
    tot=sum(len(p['I']) for p in parts)//3;allp=np.concatenate([p['P'] for p in parts]);lo=allp.min(0);hi=allp.max(0)
    tf(parts,lo,hi);out=bytearray(struct.pack('<i',len(parts)));T=0
    for p in parts:
        P,N,Uv,I=decim(p['P'],p['N'],p['U'],p['I'],max(40,int(target*len(p['I'])//3/tot)))
        assert len(P)<65536;T+=len(I)//3;fnm=(p['tx'] if p['tx']!=-1 else '').encode()
        out+=struct.pack('<ii4fi',len(P),len(I),*p['col'][:4],len(fnm))+fnm+np.c_[P,N,Uv].astype('<f4').tobytes()+I.astype('<u2').tobytes()
    open(OUT+'m/'+fn,'wb').write(out);print(fn,T,'tris',len(out)//1024,'KB')
def fit(h,axis,ground=True):
    def f(parts,lo,hi):
        s=h/(hi-lo)[axis];c=(lo+hi)/2;off=np.array([c[0],lo[1] if ground else c[1],c[2]])
        for p in parts:p['P']=(p['P']-off)*s
    return f
# gun: length axis X -> 0.7m, centered
write('gun.bin',collect('تفنگ.glb',name='gun',mx=1024),12000,fit(0.7,0,False))
pr=collect('سه_سرباز.glb',name='sol')
xs=sorted(set(round(p['bb'][0],3) for p in pr));gaps=sorted(range(len(xs)-1),key=lambda k:-(xs[k+1]-xs[k]))[:2];cuts=sorted((xs[k]+xs[k+1])/2 for k in gaps)
for s in range(3):
    gp=[p for p in pr if sum(p['bb'][0]>c for c in cuts)==s];print('soldier',s,len(gp),'parts');write('sol%d.bin'%s,[dict(p) for p in gp],7000,fit(1.8,1))
write('tank.bin',collect('تانک3.glb',root=3,name='tank'),16000,fit(9.5,2))
write('heli.bin',collect('هلیکوپتر_جنگی.glb',root=3,skip=('wreck',),name='heli'),12000,fit(12,2,False))
write('sandbag.bin',collect('کیسه_شن_.glb',name='bag'),3000,fit(1.0,0))
write('wire.bin',collect('سیم_خاردا_ر.glb',name='wire'),5000,fit(6,2))
